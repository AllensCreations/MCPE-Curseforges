## Skill: .agents/skills/mcpe-context7/SKILL.md

```markdown
---
name: mcpe-context7
description: Use before looking up ANY Bedrock API member, vanilla id, texture, recipe, component, manifest field or version for the MCPE-Curseforges repo. Routes each need to one of the three Context7 libraries and says when a script must come from the kit zip instead.
---

# mcpe-context7: Where to Look Things Up

## Authority

- `INSTRUCTIONS.md` 1.16 (copy in the kit zip's instruction files) is the policy. This skill is only its routing table and never overrides it.
- Repo rules, scripts and pack files come from the **kit zip** (`New-Pack.zip`, `Maintenance.zip` or the pack's review zip), NOT from Context7. The zip is always fresher.

## Libraries (ONLY these three, IDs exactly, `query-docs` only)

- `/microsoftdocs/minecraft-creator`: `@minecraft/server` and `@minecraft/server-ui` API, JSON schemas, stable and module versions.
- `/mojang/bedrock-samples`: vanilla ids, textures, recipes, components, entities, formats, `version.json`.
- `/websites/wiki_bedrock_dev`: manifest structure, scripting guides, techniques.

NEVER call `resolve-library-id`. NEVER query any other library.

## Repo lookups (from the kit zip, NOT Context7)

Repo rules, scripts, instruction files, `DOCS_RULES.md`, `PACK_GENERATOR_INSTRUCTIONS.md`, `docs/mcicons-index.md`, `docs/bedrock-guide.md` and all script files come from the kit zip under `files/`. Read them from there. Context7 no longer indexes this repo.

## Rules

1. Query first, write second. Batch: at most ONE `query-docs` call per needed `libraryId`, covering every topic needed from it. NEVER two calls to the same `libraryId`. Name the exact member, file, id or schema and the game or module version. All three calls may go in one parallel turn.
2. Verify every import, class, method, property and JSON field against the retrieved text. NEVER `mojang-minecraft`, `world.events` or 1.x syntax.
3. Empty or doubtful result: no sequential retry loop. Say "not verified". NEVER fill the gap from memory.
4. Versions come only from retrieved text. State the exact version used and the query date.
5. Handoff bullet: `Docs queried (YYYY-MM-DD): <library IDs and topics>`.
6. Library IDs, query text and the word Context7 NEVER go into shipped files or player-facing docs.

## Scripts that must run

- `make_pack_script.py`, `build_payload.py`, `import_project_payload.py`, `doc_template.py`, `pixel_json_to_png.py`, `make_update_script.py` and `apply_update.py` need their COMPLETE unchanged text.
- The complete files are in the kit zip (`New-Pack.zip`, `Maintenance.zip` or the pack's review zip `<Pack>.zip`) under `files/`. Unzip, run from there, NEVER retype or edit them.
- No zip: stop and ask the user to attach the zip. NEVER rewrite a script from memory.

## Icons (MCicons)

- Any vanilla item or block icon (recipe diagrams, sprites, README or listing images, UI art): use MCicons ONLY. It is the release file `reference/mcicons/mcicons-<ver>.tgz` in the repo (`package/dist/icons/minecraft_<id>.png`, 64x64, only `minecraft:` ids). Read it with `scripts/lib/mcicons.py` (`has_icon(id)`, `icon_image(id)`), never retype or guess a PNG.
- No icon for the id (custom ids, newer items): report it. NO fallback to Samples, the Wiki, another icon site or a third-party pack.
- `docs/mcicons-index.md` (in the kit zip under `files/`) lists every icon id it holds: check it before using an icon.
- The `.tgz` itself is not in the kit zips. To run code that reads the pixels it must be in the clone; if it is missing, ask the user to attach it. NEVER substitute a lookalike.
- Every manifest (BP and RP) carries `metadata.authors` = `["ALNStudios"]` and `metadata.product_type` = `"addon"`, always.
- Keep its `ASSET-NOTICE.md` with any redistributed icon.

## Reading the directory map

- The map lists directories with file counts. Pick the folder, then read the file from the zip. For exact file text of a pack, ask for a Collect Files export of that path.
- NEVER edit generated folders and files: `builds/`, `Package/`, `changelog_views/`, `MCPEDL/AI Review/`, `MCPEDL/README.md`, `builds/README.md`.
```

## Skill: .agents/skills/mcpe-new-pack/SKILL.md

```markdown
---
name: mcpe-new-pack
description: Create a NEW addon, map, script or minigame for the MCPE-Curseforges repo. Use for any "new pack", "make me an addon/map/script/minigame" request. Read this first; it sets the reading order and the checks that are most often skipped.
---

# mcpe-new-pack: Build a New Pack

## Authority

- This skill is the entry point and a checklist. It never restates or overrides policy. The rules live in `PACK_GENERATOR_INSTRUCTIONS.md` (Part 4), `INSTRUCTIONS.md` and `DOCS_RULES.md`. On any conflict `INSTRUCTIONS.md` wins, then `DOCS_RULES.md`, then the generator file.
- The complete scripts below are in `New-Pack.zip` (the kit zip) under `files/`: unzip and run them, never retype them. Everything else is read through Context7 (`mcpe-context7` skill); `New-Pack_tools.txt` (inside the same zip) holds only a directory map and the skills.
- If a required file cannot be read, stop and say which one. NEVER work from memory or from an old copy.
- Updating an existing pack is a different job: use the `mcpe-pack-update` skill and `INSTRUCTIONS.md` "Termux Script Rules".

## Do these in order

1. **Read first, then build.** `INSTRUCTIONS.md` (Reply Format, Termux Script Rules, 1.1 to 1.4, 1.7, 1.12), then `DOCS_RULES.md` (2.1 to 2.5), then ALL of `PACK_GENERATOR_INSTRUCTIONS.md`. Read these from the kit zip (`New-Pack.zip`) under `files/` — the zip always wins over any external index. Then read the scripts that decide what passes: `scripts/build_payload.py`, `scripts/doc_template.py`, `scripts/import_project_payload.py`, `scripts/make_pack_script.py` (plus `scripts/pixel_json_to_png.py` when drawing textures).
2. **Type.** If the user did not say addon, map, script or minigame, ask the exact question in 4.0 and wait. NEVER guess.
3. **Research & Plan (~90% confidence).** Conduct thorough research (~90% completeness) on requested mechanics, vanilla Bedrock components, dependencies, and latest Bedrock Script APIs. Query Context7 (`/microsoftdocs/minecraft-creator`, `/mojang/bedrock-samples`, `/websites/wiki_bedrock_dev`) for the latest stable Bedrock release and `@minecraft/server` / `@minecraft/server-ui` versions now, and verify every API member and JSON field before using it. Record the date. Present the structured Plan to the user (architecture, APIs, components, files, UX) and wait for user approval or changes before building any files.
4. **Build** the project in scratch `build/<Name>/` using the 4.2 layout (after user approves the plan). Fresh v4 UUIDs for every header and module. Write the BP manifest (with the looked-up `min_engine_version`) BEFORE running the script.
   Icons: vanilla item and block icons from MCicons only (`mcpe-context7` skill, Icons section; no fallback); custom textures only as pixel JSON.
5. **Run `scripts/make_pack_script.py build/<Name>`.** Fix every failure, including every `DOC:` line, and rerun until SELF-TEST PASSED, PACK SCRIPT OK and BUILD OK print. Then `python3 doc_template.py --style build/<Name>`, rewrite every STYLE hint with a specific fact, rebuild.
6. **Deliver** exactly ONE file: `<Name>_<Version>_<Rand>.sh`. Reply in the three sections of 4.11 and nothing else.

## Most often missed

- NEVER write base64, a ZIP or the `.sh` by hand. NEVER hand-edit the `.sh`. Cannot run code: reply `CANNOT BUILD`.
- No other deliverable: no `.zip`, `.mcaddon`, `.mcworld`, `.mcpack`, `.json`, `.js`, `.b64`. `build/` is scratch and is never delivered.
- There is no test world. NEVER ship `test_world.json` (the build rejects it) and NEVER promise a `- Test.mcworld`.
- The importer creates `assets/snapshots`, `assets/recipes` and `assets/items` for the pack. NEVER ship `assets/`, `Mcpeworlds/` or listing images in the payload.
- Every custom crafting recipe needs `AlwaysUnlocked` (1.4). Every custom recipe and item shown in DESCRIPTION gets its image from `scripts/generate_recipe_images.py` after import (1.5).
- Docs follow the templates in `DOCS_RULES.md` 2.5 exactly: README is the 11-line download landing page, DESCRIPTION has the exact section order, both badges and both listing images, and says `not tested in game`, the achievement status and the experiments status.
- No comments in `.js`, `.mcfunction` or `.json`. Versions are `X.Y.Z` only. `by ALNStudios` appears once per description, never in a name.
- Map: `void_cleaner` first in `tick.json`, exact fill line, conditional `void_cleaned` tag, Trader Ledger from the repo copy. Minigame: Controller from the repo copy (it already is the ALN UI Redesign menu: never edit or replace it), `registerController` with `title`, `version` equal to the BP manifest, `about`, real `gameInfo` and `howToPlay` with no color codes, real logic that calls `endGame()`. NEVER build your own form. Script: Behavior Pack only, `.mcpack`.
- Never claim anything was tested in Minecraft. The checks prove structure only.

## After the pack is in the repo

- Register the CurseForge project ID with the **Register CurseForge ID** workflow. It saves the ID, refreshes the publish dropdown and then starts **Build Changed Packs & Sync Catalogs** by itself. Nothing else needs to be run by hand.
- Versions never change on a build. Only an update script or **Publish to CurseForge** moves them.

## Before replying (tick every line)

- [ ] I read the three instruction files and the four scripts through Context7 or this export, not from memory, and every API member was verified in a query result.
- [ ] Type was given or asked. Versions and `min_engine_version` were looked up today and the date is recorded.
- [ ] SELF-TEST PASSED, PACK SCRIPT OK and BUILD OK were printed by a real run; exactly one `.sh` exists.
- [ ] No `DOC:` failures, no STYLE hints, no placeholders, no `test_world.json`, no `assets/` in the payload.
- [ ] Reply = **File Needed**, **Changelog**, **Termux Script**, in that order, no text before, between or after, no Summary. The `.sh` is attached, never pasted.
- [ ] Finished output saved in AI memory: the pack name, version, and generation details are saved in persistent AI memory.
```

# Repo Map (directories only)

No file contents are pasted here on purpose. Rules, docs and script source are read through Context7 `query-docs` (see the `mcpe-context7` skill above). Do not ask for a full dump.

The complete, unchanged scripts this task has to RUN are in the same kit zip as this file, under `files/`: unzip and run them, never retype them.

- `files/scripts/make_pack_script.py`
- `files/scripts/build_payload.py`
- `files/scripts/import_project_payload.py`
- `files/scripts/doc_template.py`
- `files/scripts/pixel_json_to_png.py`
- `files/docs/mcicons-index.md`
- `files/INSTRUCTIONS.md`
- `files/DOCS_RULES.md`
- `files/PACK_GENERATOR_INSTRUCTIONS.md`
- `files/assets/aln-ui-redesign/README.txt`
- `files/assets/aln-ui-redesign/design.json`
- `files/assets/aln-ui-redesign/font/README.txt`
- `files/assets/aln-ui-redesign/font/pixelify.js`

Project version and release notes: see the pack's own `CHANGELOG.md`. The repo's files win over any cached Context7 index.

## Directories

- `.agents/` (5 files)
- `.agents/rules/` (1 file)
- `.agents/skills/` (4 files): agent skills, one folder each
- `.agents/skills/checkrm/` (1 file)
- `.agents/skills/mcpe-context7/` (1 file)
- `.agents/skills/mcpe-new-pack/` (1 file)
- `.agents/skills/mcpe-pack-update/` (1 file)
- `.github/` (13 files)
- `.github/workflows/` (12 files): CI and dispatch workflows
- `archive/` (9 files): old material
- `assets/` (46 files): shared images and the ALN UI Redesign skin
- `assets/aln-ui-redesign/` (18 files): shared UI skin (read for any pack with a menu)
- `assets/aln-ui-redesign/font/` (4 files)
- `assets/aln-ui-redesign/textures/` (10 files)
- `assets/fonts/` (2 files)
- `assets/Images/` (4 files)
- `assets/labels/` (22 files)
- `builds/` (701 files): GENERATED packages, never edit
- `changelog_views/` (138 files): GENERATED changelog views, never edit
- `dashboard/` (16 files): web dashboard
- `docs/` (4 files): the ONLY folder Context7 indexes: rules, script summaries, Bedrock guide (query it, do not dump it)
- `graphify-out/` (7 files): GENERATED repo graph
- `MCPEDL/` (5017 files): all projects: Addons, Maps, Script, Minigame
- `MCPEDL/Addons/` (46 projects)
- `MCPEDL/AI Review/` (235 files)
- `MCPEDL/incoming/` (6 files)
- `MCPEDL/Maps/` (6 projects)
- `MCPEDL/Minigame/` (6 projects)
- `MCPEDL/Script/` (11 projects)
- `mcpeworlds/` (3 files)
- `mcpeworlds/Progression/` (2 files)
- `Mcpeworlds/` (28 files): map templates and shared map assets
- `Package/` (76 files): GENERATED listing kits, never edit
- `reference/` (1044 files): vanilla Bedrock reference data
- `scripts/` (106 files): build, validate, package and update tooling (run it, do not retype it)
- `scripts/lib/` (8 files)
- `scripts/output/` (2 files)

Inside every `MCPEDL/<Category>/<Name>/` project (how many projects have it): `assets/` (69), `behavior_pack/` (69), `resource_pack/` (46), `texture_sources/` (21), `sound_sources/` (1), `world/` (1).
