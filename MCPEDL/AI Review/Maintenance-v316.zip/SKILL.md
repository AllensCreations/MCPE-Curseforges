## Skill: .agents/skills/mcpe-context7/SKILL.md

```markdown
---
name: mcpe-context7
description: Use before looking up ANY Bedrock API member, vanilla id, texture, recipe, component, manifest field or version for the MCPE-Curseforges repo. Routes each need to one of the three Context7 libraries and says when a script must come from the kit zip instead.
---

# mcpe-context7: Where to Look Things Up

## Authority

- `INSTRUCTIONS.md` 1.16 (copy in the kit zip's instruction files) is the policy. This skill is only its routing table and never overrides it.
- Repo rules, scripts and pack files come from the **kit zip** (`New-Pack.zip`, `Maintenance.zip` or the pack's review zip), NOT from Context7. The zip is always fresher.

## Libraries (ONLY these three, IDs exactly, `query-docs` only)

- `/microsoftdocs/minecraft-creator`: `@minecraft/server` and `@minecraft/server-ui` API, JSON schemas, stable and module versions.
- `/mojang/bedrock-samples`: vanilla ids, textures, recipes, components, entities, formats, `version.json`.
- `/websites/wiki_bedrock_dev`: manifest structure, scripting guides, techniques.

NEVER call `resolve-library-id`. NEVER query any other library.

## Repo lookups (from the kit zip, NOT Context7)

Repo rules, scripts, instruction files, `DOCS_RULES.md`, `PACK_GENERATOR_INSTRUCTIONS.md`, `docs/mcicons-index.md`, `docs/bedrock-guide.md` and all script files come from the kit zip under `files/`. Read them from there. Context7 no longer indexes this repo.

## Rules

1. Query first, write second. Batch: at most ONE `query-docs` call per needed `libraryId`, covering every topic needed from it. NEVER two calls to the same `libraryId`. Name the exact member, file, id or schema and the game or module version. All three calls may go in one parallel turn.
2. Verify every import, class, method, property and JSON field against the retrieved text. NEVER `mojang-minecraft`, `world.events` or 1.x syntax.
3. Empty or doubtful result: no sequential retry loop. Say "not verified". NEVER fill the gap from memory.
4. Versions come only from retrieved text. State the exact version used and the query date.
5. Handoff bullet: `Docs queried (YYYY-MM-DD): <library IDs and topics>`.
6. Library IDs, query text and the word Context7 NEVER go into shipped files or player-facing docs.

## Scripts that must run

- `make_pack_script.py`, `build_payload.py`, `import_project_payload.py`, `doc_template.py`, `pixel_json_to_png.py`, `make_update_script.py` and `apply_update.py` need their COMPLETE unchanged text.
- The complete files are in the kit zip (`New-Pack.zip`, `Maintenance.zip` or the pack's review zip `<Pack>.zip`) under `files/`. Unzip, run from there, NEVER retype or edit them.
- No zip: stop and ask the user to attach the zip. NEVER rewrite a script from memory.

## Icons (MCicons)

- Any vanilla item or block icon (recipe diagrams, sprites, README or listing images, UI art): use MCicons ONLY. It is the release file `reference/mcicons/mcicons-<ver>.tgz` in the repo (`package/dist/icons/minecraft_<id>.png`, 64x64, only `minecraft:` ids). Read it with `scripts/lib/mcicons.py` (`has_icon(id)`, `icon_image(id)`), never retype or guess a PNG.
- No icon for the id (custom ids, newer items): report it. NO fallback to Samples, the Wiki, another icon site or a third-party pack.
- `docs/mcicons-index.md` (in the kit zip under `files/`) lists every icon id it holds: check it before using an icon.
- The `.tgz` itself is not in the kit zips. To run code that reads the pixels it must be in the clone; if it is missing, ask the user to attach it. NEVER substitute a lookalike.
- Every manifest (BP and RP) carries `metadata.authors` = `["ALNStudios"]` and `metadata.product_type` = `"addon"`, always.
- Keep its `ASSET-NOTICE.md` with any redistributed icon.

## Reading the directory map

- The map lists directories with file counts. Pick the folder, then read the file from the zip. For exact file text of a pack, ask for a Collect Files export of that path.
- NEVER edit generated folders and files: `builds/`, `Package/`, `changelog_views/`, `MCPEDL/AI Review/`, `MCPEDL/README.md`, `builds/README.md`.
```

## Skill: .agents/skills/mcpe-pack-update/SKILL.md

````markdown
---
name: mcpe-pack-update
description: Use for any change to an existing project, workflow, script or doc in the MCPE-Curseforges repository (update, fix, add, rename). Delivers every change as ONE self-contained Termux update script (<Pack>_v<Version>_<rand>.sh) containing the spec and rich UI.
---

# mcpe-pack-update: Update Delivery

## Authority

- `INSTRUCTIONS.md` is the policy source. `PACK_GENERATOR_INSTRUCTIONS.md` is its standalone copy for generation. The script flow is `INSTRUCTIONS.md` "Termux Script Rules", built with `scripts/make_update_script.py`. Where to look each rule up: the `mcpe-context7` skill. This skill is a short working checklist and never restates or overrides them.
- **Precedence** (as in `PACK_GENERATOR_INSTRUCTIONS.md`): factual accuracy and the user's requested scope, then Part 1, then Part 2, then this skill. Part 4 of the generator file never overrides Parts 1 and 2.
- If these files disagree with each other or with a script in `scripts/`, tell the user exactly what differs instead of choosing silently. If `INSTRUCTIONS.md` cannot be read, stop and report it instead of working from memory.
- Achievements line (every project type): always `Yes, achievement-friendly.` Keep any cheats or world-setting caveat as a following sentence.

## Scope

- Use for changes to an existing project (`MCPEDL/Addons|Maps|Script|Minigame/<Name>/`), a workflow, a script, a catalog or any repo doc.
- Read-only audit or report: use `checkrm`.
- New project from an idea: follow `PACK_GENERATOR_INSTRUCTIONS.md` Part 4 (ask the type first, base64 payload).

## Procedure

1. Read `INSTRUCTIONS.md` Parts 1 and 2 before writing anything, through Context7 as the `mcpe-context7` skill says. `make_update_script.py`, `apply_update.py`, and `pixel_json_to_png.py` are complete in the pack's review zip (`<Pack>.zip`) under `files/`; run them from there.
2. Find the destination folder: the path the user named, otherwise the matching project folder. Do not substitute a similar name; report ambiguity or a missing target.
3. Read the real source (manifests, scripts, items, recipes, loot tables, functions, lang files) before writing any claim. Source priority when sources disagree: the project's own files, Mojang Bedrock Samples, official Minecraft Creator Documentation, Minecraft Wiki, Bedrock Wiki.
4. Make the smallest possible change. No unrelated rewrites. Never invent features, versions, links, assets, test results or compatibility. Never write comments in shipped `.js`, `.mcfunction` or `.json` files.
5. Generate the spec, convert it with `make_update_script.py` into a single self-contained `<Pack>_v<Version>_<rand>.sh` file, and provide the one-line run command for the user.

## The update script

Generate the spec with `apply_update.py` directives (replace, replace-all, insert-after, insert-before, create, overwrite, delete, changelog).
Then build the single `.sh` using:
```bash
python3 files/scripts/make_update_script.py spec.txt --out-dir .
```
This produces ONE single `.sh` file (`<PackName>_v<Version>_<rand>.sh`) that contains the embedded update payload, ANSI colored status UI, automated git rebase, validation checks, commit, and push.

## Reply

1. Attach or output the single `.sh` file (`<PackName>_v<Version>_<rand>.sh`).
2. Give the single Termux command:
```bash
bash ~/storage/downloads/<PackName>_v<Version>_*.sh
```
3. Brief summary of what changed and what checks ran.
4. **Save in AI memory**: Every finished output, applied change summary, and spec version must be retained in AI memory/scratch notes so context is preserved across turns without relying on session replay.
````

# Repo Map (directories only)

No file contents are pasted here on purpose. Rules, docs and script source are read through Context7 `query-docs` (see the `mcpe-context7` skill above). Do not ask for a full dump.

The complete, unchanged scripts this task has to RUN are in the same kit zip as this file, under `files/`: unzip and run them, never retype them.

- `files/scripts/make_update_script.py`
- `files/scripts/apply_update.py`
- `files/scripts/check_instruction_files.py`
- `files/docs/mcicons-index.md`
- `files/INSTRUCTIONS.md`
- `files/DOCS_RULES.md`
- `files/PACK_GENERATOR_INSTRUCTIONS.md`

Project version and release notes: see the pack's own `CHANGELOG.md`. The repo's files win over any cached Context7 index.

## Directories

- `.agents/` (5 files)
- `.agents/rules/` (1 file)
- `.agents/skills/` (4 files): agent skills, one folder each
- `.agents/skills/checkrm/` (1 file)
- `.agents/skills/mcpe-context7/` (1 file)
- `.agents/skills/mcpe-new-pack/` (1 file)
- `.agents/skills/mcpe-pack-update/` (1 file)
- `.github/` (13 files)
- `.github/workflows/` (12 files): CI and dispatch workflows
- `archive/` (9 files): old material
- `assets/` (46 files): shared images and the ALN UI Redesign skin
- `assets/aln-ui-redesign/` (18 files): shared UI skin (read for any pack with a menu)
- `assets/aln-ui-redesign/font/` (4 files)
- `assets/aln-ui-redesign/textures/` (10 files)
- `assets/fonts/` (2 files)
- `assets/Images/` (4 files)
- `assets/labels/` (22 files)
- `builds/` (701 files): GENERATED packages, never edit
- `changelog_views/` (138 files): GENERATED changelog views, never edit
- `dashboard/` (16 files): web dashboard
- `docs/` (4 files): the ONLY folder Context7 indexes: rules, script summaries, Bedrock guide (query it, do not dump it)
- `graphify-out/` (7 files): GENERATED repo graph
- `MCPEDL/` (5017 files): all projects: Addons, Maps, Script, Minigame
- `MCPEDL/Addons/` (46 projects)
- `MCPEDL/AI Review/` (235 files)
- `MCPEDL/incoming/` (6 files)
- `MCPEDL/Maps/` (6 projects)
- `MCPEDL/Minigame/` (6 projects)
- `MCPEDL/Script/` (11 projects)
- `mcpeworlds/` (3 files)
- `mcpeworlds/Progression/` (2 files)
- `Mcpeworlds/` (28 files): map templates and shared map assets
- `Package/` (76 files): GENERATED listing kits, never edit
- `reference/` (1044 files): vanilla Bedrock reference data
- `scripts/` (106 files): build, validate, package and update tooling (run it, do not retype it)
- `scripts/lib/` (8 files)
- `scripts/output/` (2 files)

Inside every `MCPEDL/<Category>/<Name>/` project (how many projects have it): `assets/` (69), `behavior_pack/` (69), `resource_pack/` (46), `texture_sources/` (21), `sound_sources/` (1), `world/` (1).
