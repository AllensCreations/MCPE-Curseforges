# OneBlock: Sovereign Market — Dirt-to-Sovereignty OneBlock Economy

**By ALNStudios**

[![Minecraft Bedrock](https://img.shields.io/badge/Minecraft%20Bedrock-Stable%20Release-brightgreen?style=flat-square&logo=minecraft)](https://github.com/AllensCreations/MCPE-Curseforges)
[![Format](https://img.shields.io/badge/Format-.MCPACK%20%7C%20.MCADDON%20%7C%20.MCWORLD-blue?style=flat-square)](https://github.com/AllensCreations/MCPE-Curseforges)

- Start on a small 9 x 9 void island with one OneBlock that produces Dirt. A short How to Play guide opens first and must be read once.
- Mining the OneBlock gives you items. Dirt sells for 1 :minecoin: each in the Trader's Ledger, like every other item.
- Trader's Ledger: sell items, read market prices, buy block licenses, activate loot contracts, buy island permits, buy the Auto-Miner, and review your achievements. The ledger is an item kept in hotbar slot 9 for every player.
- How to Play: a short in-game guide in the Ledger, plus a hint at the top of the menu that follows your progress. Finishing the guide earns the Quick Learner achievement.
- One-tap shop: every license, contract, island permit and auto-mine purchase is a single button. Tap to buy; the button then shows its next state (Owned, Upgrade, MAX). Purchases of 2,000 coins or more ask for confirmation first.
- Ten license tiers widen the pool of blocks the OneBlock can produce. Only naturally generated blocks appear (logs, ores, stone, sand, nether and end blocks, and more). Rare blocks stay rare, and liquids never appear.
- Market prices respond to supply (your recent sales) and a rotating demand schedule.
- Six Natural Loot Contracts, with loot limited to what your licenses allow. Five spawn loot chests on your island over time; the Basic Supply Chest instead makes the OneBlock itself sometimes turn into a loot chest. Each contract can be upgraded to level 3 for an extra loot roll and a faster wait or higher chest chance. About one island chest in ten is a golden chest with bonus gems.
- Auto-Miner: five permanent levels named after tools (Wooden, Copper, Iron, Gold, Diamond) that break the OneBlock every 10, 6, 4, 2, then 1 tick, with the block-destroy animation on every break. It runs about 2 minutes per Minecraft day, then reports that auto-mining is exhausted. Drops go into a chest directly above the OneBlock, and it has an ON/OFF toggle. If something blocks the spot for the collection chest, it tells you on the action bar. Mining time does not run while that chest is full.
- Every 100th break pays a coin bonus and turns the next OneBlock into a bonus loot chest. About 1 break in 100 produces a gold block jackpot that pays coins when broken.
- Six achievements pay one-time coin rewards.
- Island permits grow the build area 9, 17, 33, 65, then 1 block per side at a time (67, 69, 71 and so on up to 129). Only the border is drawn, just outside the permitted area, so you build your own land inside it. Building outside your plot shows a "Plot not owned" warning.
- Stray water and lava are removed from the island area every 30 seconds.

## Compatibility

- Minecraft Bedrock Edition: 1.26.40 or newer.
- Experimental features: Not verified.
- Achievements: Unknown / needs confirmation.
- Verification: Source created, not tested in game.

## Creator and Permissions

- Creator: ALNStudios
- Profiles: [CurseForge Profile](https://www.curseforge.com/members/allenscreations/projects) · [MCPEDL Profile](https://mcpedl.com/user/allenscreations/)

<a href="https://www.curseforge.com/members/allenscreations/projects"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/curseforge.jpg" alt="CurseForge" width="45%"></a> <a href="https://mcpedl.com/user/allenscreations/"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/MCPEDL.jpg" alt="MCPEDL" width="45%"></a>
- [MCPEDL Profile](https://mcpedl.com/user/alnstudios/)

<a href="https://www.curseforge.com/members/allenscreations/projects"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/curseforge.jpg" alt="CurseForge" width="45%"></a> <a href="https://mcpedl.com/user/alnstudios/"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/MCPEDL.jpg" alt="MCPEDL" width="45%"></a>

## Guidelines and Attribution

- Creator: ALNStudios
- Rights & Reservation: All rights reserved for ALNStudios.
- Content Creators: Content creators are permitted to feature this creation in videos and streams with credit to ALNStudios.
- Redistribution: Do not re-upload this pack or provide direct monetized download bypasses. Link directly to the official repository page.
- Disclaimer: This is an unofficial community creation. It is not an official Minecraft product and is not approved by or associated with Mojang or Microsoft.

---

© All rights reserved for ALNStudios.

---

## Search & Discovery Keywords

Minecraft Bedrock add-on, OneBlock Sovereign Market Bedrock mod, Minecraft PE survival, MCPEDL add-on, CurseForge Bedrock, ALNStudios.

