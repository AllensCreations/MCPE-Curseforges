# Universal Clutch — Intelligent Fall Mitigation Script

**By ALNStudios**

[![Minecraft Bedrock](https://img.shields.io/badge/Minecraft%20Bedrock-Stable%20Release-brightgreen?style=flat-square&logo=minecraft)](https://github.com/AllensCreations/MCPE-Curseforges)
[![Format](https://img.shields.io/badge/Format-.MCPACK%20%7C%20.MCADDON%20%7C%20.MCWORLD-blue?style=flat-square)](https://github.com/AllensCreations/MCPE-Curseforges)

**AUTOMATIC CLUTCH SYSTEM & FALL PROTECTION UTILITY**

Automatically attempts a clutch when you fall while looking toward the ground. Supported items can reduce or prevent fall damage, and placed water or powder snow may be collected again after landing.

---

## Overview

Universal Clutch provides a vanilla-faithful safety mechanic for Minecraft Bedrock players. The system checks your fall and whether you are looking toward the ground.

When aiming down and falling beyond the configured block height threshold, the add-on acts shortly before impact, triggers an authentic arm swing animation with placement audio, deploys the appropriate clutch item from your mainhand or offhand, and automatically re-scoops placed water upon touchdown.

---

## Key Features

### Multi-Item Clutch Support
- **Description**: Automatically identifies and uses Water Buckets, Powder Snow Buckets, Twisting Vines, Hay Bales, Cobwebs, Slime Blocks, Scaffolding, Boats/Rafts, or Sweet Berries.

### Dimension-Aware Clutches
- **Description**: Automatically disables evaporating Water Buckets in the Nether, prioritizing Twisting Vines & Powder Snow Buckets instead.

### Dual Hand & Inventory Detection
- **Description**: Evaluates mainhand items first, with failover to offhand, hotbar, and upper inventory.

### Totem of Undying Fail-Safe
- **Description**: When falling to certain death with no clutch item, automatically searches inventory and equips a Totem of Undying into the offhand slot before impact.

### Authentic Boat Placement
- **Description**: Spawns the boat at maximum player reach distance (~4.5 blocks) first, then seats the player with a slight delay upon touchdown. Strictly no teleportation.

### Timed Placement
- **Description**: Uses velocity-based vertical raycasting to trigger placements shortly before impact rather than snapping prematurely.

### Arm Placement Animation
- **Description**: Triggers vanilla arm swing animations (the standard arm-swing animation) synced directly to placement audio.

### Automatic Item Recovery
- **Description**: Automatically retrieves placed water or powder snow 3 ticks after touchdown; verifies powder snow wasn't consumed to extinguish fire before re-scooping.

---

## Supported Clutch Items and Behaviors

### Water Bucket
- **Placement Target**: Impact Air Block
- **Effect**: Negates fall damage; auto-scooped 3 ticks after landing (disabled in Nether)

### Powder Snow Bucket
- **Placement Target**: Impact Air Block
- **Effect**: Absorbs fall damage; auto-scooped 3 ticks after landing (unless melted by fire)

### Twisting Vines
- **Placement Target**: Top Face of Solid Ground Block
- **Effect**: Nether-native climbing vine; resets vertical momentum and absorbs fall damage

### Hay Bale
- **Placement Target**: Impact Air Block
- **Effect**: Reduces fall damage by 80% upon touchdown

### Cobweb
- **Placement Target**: Impact Air Block
- **Effect**: Decelerates player velocity and completely negates fall damage

### Slime Block
- **Placement Target**: Impact Air Block
- **Effect**: Completely eliminates fall damage and bounces player upward

### Scaffolding
- **Placement Target**: Impact Air Block
- **Effect**: Traverses falling entity momentum and absorbs fall damage

### Boat / Raft
- **Placement Target**: Impact Air Coordinate
- **Effect**: Placed at max reach distance (~4.5 blocks) first, auto-riding player with slight delay

### Sweet Berries
- **Placement Target**: Impact Air Block
- **Effect**: Places sweet berry bush to decelerate and cancel fall damage

### Totem of Undying
- **Placement Target**: Offhand Slot (Emergency Swap)
- **Effect**: Auto-equipped when falling with no clutch items to attempt to prevent a fatal fall

---

## When It Activates

The player must be falling from the selected height threshold while looking down (not required in Extreme Mode), and the add-on attempts placement close to impact.

---

---

## Operating Modes & Subpack Configuration

Universal Clutch supports three distinct operating modes selectable via subpack settings slider in World Settings or customizable per-player in-game:

Each player can turn Universal Clutch off or on with the commands `/scriptevent clutch:off` and `/scriptevent clutch:on` (cheats required). The setting is saved per player.

### Operating Modes

- **Full Mode (Auto-Switch Inventory):**
  If a clutch item is not already held in hand, the system automatically scans your hotbar and upper inventory for available clutch items, switches or swaps it directly into your active hand, executes the clutch placement, and remains holding the switched item. Requires the player to aim downward (looking down toward the ground).
- **Simple Mode (Held Item Only):**
  Clutch placements only trigger if you are actively holding a supported clutch item in your mainhand or offhand slot. If holding a sword, pickaxe, or empty hand, no placement will occur. Requires the player to aim downward (looking down toward the ground).
- **Extreme Mode (Auto-Switch, No Look-Down Needed):**
  When falling from dangerous heights, the add-on does not require you to look down, scans and auto-switches to the best available clutch item in inventory, places it 1–2 ticks before impact, and remains holding the switched item. **No-Item Limitation:** If no suitable clutch item is available, the add-on cannot assist with the fall.

### Built-in Subpack Presets

Configurable via the Behavior Pack subpack settings slider in World Settings:

1. **Full Mode (Auto-Switch Inventory):** Recommended default. Automatically detects, equips, and places clutch items from inventory, keeping the switched item active.
2. **Simple Mode (Held Item Only):** Traditional manual clutching. Only executes if a supported clutch item is already held in mainhand or offhand.
3. **Extreme Mode (Auto-Switch, No Look-Down Needed):** Hands-free safety system with auto item switching that works without looking down. If inventory has no clutch item, the add-on cannot assist.

#---

## Highlights & Performance

- **Responsive Clutch Engine**: Attempts to place a suitable item shortly before impact; success depends on the fall and available items.
- **Survival Balanced**: Consumes clutch items faithfully from your inventory or hand in Survival and Adventure modes.
- **Anti-Spam Cooldown**: Built-in placement cooldown guarantees one clean clutch per fall.

---

## Compatibility

- Minecraft Bedrock Edition 1.21.0+
- Compatible with Bedrock 1.21.50+ and 1.26.0+ releases
- Check the current pack listing for setup requirements.
- Multiplayer behavior should be checked in the target game version.

---
- Experimental features: Not verified.
- Achievements: Likely achievement-friendly.
- Verification: Source created, not tested in game.

## Creator and Permissions

- Creator: ALNStudios
- Profiles: [CurseForge Profile](https://www.curseforge.com/members/allenscreations/projects) · [MCPEDL Profile](https://mcpedl.com/user/allenscreations/)

<a href="https://www.curseforge.com/members/allenscreations/projects"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/curseforge.jpg" alt="CurseForge" width="45%"></a> <a href="https://mcpedl.com/user/allenscreations/"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/MCPEDL.jpg" alt="MCPEDL" width="45%"></a>
- [MCPEDL Profile](https://mcpedl.com/user/alnstudios/)

<a href="https://www.curseforge.com/members/allenscreations/projects"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/curseforge.jpg" alt="CurseForge" width="45%"></a> <a href="https://mcpedl.com/user/alnstudios/"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/MCPEDL.jpg" alt="MCPEDL" width="45%"></a>

## Guidelines and Attribution

- Creator: ALNStudios
- Rights & Reservation: All rights reserved for ALNStudios.
- Content Creators: Content creators are permitted to feature this creation in videos and streams with credit to ALNStudios.
- Redistribution: Do not re-upload this pack or provide direct monetized download bypasses. Link directly to the official repository page.
- Disclaimer: This is an unofficial community creation. It is not an official Minecraft product and is not approved by or associated with Mojang or Microsoft.

---

© All rights reserved for ALNStudios.

---

## Search & Discovery Keywords

Universal Clutch Minecraft Bedrock, Multi-Item Clutch Support Bedrock, Dimension-Aware Clutches Bedrock, Dual Hand & Inventory Detection Bedrock, Totem of Undying Fail-Safe Bedrock, Minecraft PE survival, MCPEDL, CurseForge Bedrock, ALNStudios, Minecraft Bedrock add-on, MCPEDL add-on.

