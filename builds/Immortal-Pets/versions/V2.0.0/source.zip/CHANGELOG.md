# Changelog — Immortal Pets

---

## [v2] - 2026-11-12

**What's new in v1.10.1:** Packed with the v1.10.1 update. Includes: Description and Code Cleanup.

### Improved & Balanced

- **Streamlined damage checks**: Hurt pets now go through one protection pass, with the same poison removal and health recovery as before.
- **Clearer description page**: The description now follows the standard layout, with a new How to Use section listing every protection mode.

### Fixed

- **MCPEDL profile link**: The MCPEDL profile link on the description page now points to the correct profile.

## [1.10.0] - 2026-10-29

### Improved & Balanced

- **Changelog started**: Version history is recorded from this release onward.
