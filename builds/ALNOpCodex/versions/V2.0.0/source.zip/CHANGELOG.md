# Changelog — ALN:OpCodex

---

## [v2] - 2026-11-27 - Menu Command and Delivery Fix

### Added
- **Menu command**: Typing /aln:alnop opens the OP book menu without the book.

### Improved & Balanced
- **Plain menu buttons**: Menu buttons no longer show emojis.
- **OP book**: A player who joins without the book receives a new one.

### Fixed
- **Kit delivery**: The pack now waits longer for a kit before reporting that it failed.

## [1.0.0] - 2026-11-27 - First Release

### Added
- **OP book**: Opens a menu with Tools and Armor, About, and Exit.
- **God kits**: Named shulker boxes with Netherite tools or armor go into your inventory.
