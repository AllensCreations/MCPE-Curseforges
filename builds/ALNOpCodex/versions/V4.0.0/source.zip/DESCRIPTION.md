# ALN:OpCodex — Netherite kits from one book

**By ALNStudios**

[![Minecraft Bedrock](https://img.shields.io/badge/Minecraft%20Bedrock-Stable%20Release-brightgreen?style=flat-square&logo=minecraft)](https://github.com/AllensCreations/MCPE-Curseforges)
[![Format](https://img.shields.io/badge/Format-.MCPACK%20%7C%20.MCADDON%20%7C%20.MCWORLD-blue?style=flat-square)](https://github.com/AllensCreations/MCPE-Curseforges)

**Use the OP book to get 9 tools including bows, or 5 Netherite armor pieces, in a named shulker box.**

> The OP book hands out two kits, OpCodex God Tools and OpCodex God Armor. It suits creative testing and private worlds where every player may have top gear.

## Overview

A player who joins without an OP book receives one. Using it opens a menu where a kit is chosen, and the filled shulker box drops to the player to be picked up.

## Key Features

### OP Book Menu
- **What Happens**: The menu offers Tools and Armor, About, and Exit. Tools and Armor leads to the two kit choices.
- **Good To Know**: Every player can use the book.

### OpCodex God Tools
- **What Happens**: A shulker box holds Fortune and Silk Touch copies of the pickaxe, axe and shovel, one sword, and Infinity and Mending bows.
- **Good To Know**: Most enchantments are prepared at level 255, including Mending. Knockback and Punch stay at 2.

### OpCodex God Armor
- **What Happens**: A shulker box holds a helmet, chestplate, leggings, Depth Strider boots and Frost Walker boots.
- **Good To Know**: Boots include Feather Falling. Soul Speed, Swift Sneak and Depth Strider stay at 3, and Frost Walker at 2.

## How to Use

1. Hold the OP book and use it.
2. Choose Tools and Armor, then Tools or Armor.
3. Place the new shulker box and open it to collect the gear.

## Commands

- `/aln:alnop`: Opens the OP book menu, even without the book.

## Common Questions

- **What do I need before picking a kit?**: One free inventory slot and some empty space above you.

- **Why did no box arrive?**: Check that block drops are turned on in the world settings or game rules.

## Compatibility

- Minecraft Bedrock Edition: version 1.26.50 is the target and is not yet verified.
- Experimental features: No experiment requirement detected in the inspected files.
- Achievements: Yes, achievement-friendly.
- Verification: Source created, not tested in game.

## Creator and Permissions

- Creator: ALNStudios
- Profiles: [CurseForge Profile](https://www.curseforge.com/members/allenscreations/projects) · [MCPEDL Profile](https://mcpedl.com/user/alnstudios/)

<a href="https://www.curseforge.com/members/allenscreations/projects"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/curseforge.jpg" alt="CurseForge" width="45%"></a> <a href="https://mcpedl.com/user/alnstudios/"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/MCPEDL.jpg" alt="MCPEDL" width="45%"></a>

## Guidelines and Attribution

- Creator: ALNStudios
- Rights & Reservation: All rights reserved for ALNStudios.
- Content Creators: Content creators are permitted to feature this creation in videos and streams with credit to ALNStudios.
- Redistribution: Do not re-upload this pack or provide direct monetized download bypasses. Link directly to the official repository page.
- Disclaimer: This is an unofficial community creation. It is not an official Minecraft product and is not approved by or associated with Mojang or Microsoft.

---

© All rights reserved for ALNStudios.

---

## Search & Discovery Keywords

Minecraft Bedrock add-on, ALN:OpCodex Bedrock mod, OP book, Netherite tools, Netherite armor, shulker box kit, MCPEDL add-on, CurseForge Bedrock, ALNStudios.

