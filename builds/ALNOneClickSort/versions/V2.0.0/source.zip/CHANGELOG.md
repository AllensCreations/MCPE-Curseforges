# Changelog — ALN:OneClickSort

---

## [2.0.0] - 2026-11-20 - Pack Variants and Restock

### Added
- **Pack Variants**: Choose Simple (default) or Normal (with particles) in the pack settings; only Normal shows particles above sorted chests.
- **Restock**: Right-click a Feather renamed Restock to refill partial stacks in your hotbar and backpack from chests, trapped chests and barrels within 6 blocks.

## [1.0.0] - 2026-11-20 - First Release

### Added
- **Backpack Sorting**: Right-click a Feather renamed Auto-Sort to sort the 27 backpack slots while the hotbar stays untouched.
- **Chest Sorting**: Sneak and right-click a chest, trapped chest, barrel or shulker box to sort it without opening it.
- **Quick Stack**: Sneak and right-click the Auto-Sort Feather to move matching items into chests and barrels within 6 blocks.
- **Sort Settings**: Right-click a Book renamed Sort Settings to choose the sort order, hotbar sorting and feedback.
