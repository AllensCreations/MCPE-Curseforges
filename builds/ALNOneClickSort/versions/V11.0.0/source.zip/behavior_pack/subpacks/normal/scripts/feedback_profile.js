export const PARTICLES = true;
