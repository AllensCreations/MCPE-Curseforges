# One-Block Hardcore Survival Economy (v1.0.1) — 20-Phase Progression Add-on

**By AllensCreations**

This Minecraft Bedrock add-on adds central-block progression, recurring Wandering Trader visits, and a void-rescue feature for a compatible OneBlock world.

## Features

### OneBlock Regeneration
- The central block returns after it is broken.
- Each break advances the saved block counter and can unlock a new phase.

### 20 Progression Phases
- The block pool changes as the total number of blocks broken increases.
- An action-bar display shows the total, current phase, and phase name.

### Wandering Trader
- A Wandering Trader arrives every 250 blocks broken.
- Each visit lasts about 60 seconds.

### Void Rescue
- Players who fall below Y = -50 are teleported back above the OneBlock.
- The rescue applies damage but is designed to leave at least one health point.

## Important World Requirement

This add-on does not generate a complete OneBlock world. Use it in a world with the central block at **(0, 64, 0)** in the Overworld.

## Compatibility

- Minimum Minecraft Bedrock version: 1.21.0.

## Creator Profiles

- [CurseForge Profile](https://www.curseforge.com/members/allenscreations/projects)
- [MCPEDL Profile](https://mcpedl.com/user/allenscreations/)

## Guidelines and Attribution

- Creator: AllensCreations
- Rights & Reservation: All rights reserved for AllensCreations.
- Content Creators: Content creators are permitted to feature this creation in videos and streams with credit to AllensCreations.
- Redistribution: Do not re-upload this pack or provide direct monetized download bypasses. Link directly to the official repository page.

---

© All rights reserved for AllensCreations.

---

## Search & Discovery Keywords

One-Block Hardcore Survival Economy Minecraft Bedrock, OneBlock Regeneration Bedrock, 20 Progression Phases Bedrock, Wandering Trader Bedrock, Void Rescue Bedrock, Minecraft PE add-on, MCPEDL, CurseForge Bedrock, AllensCreations.
