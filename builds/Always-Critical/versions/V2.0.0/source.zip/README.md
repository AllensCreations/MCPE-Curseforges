# Always Critical

<!-- CURSEFORGE-BADGE:START -->
[![CurseForge](https://img.shields.io/badge/CurseForge-v2-orange?style=flat-square&logo=curseforge)](https://www.curseforge.com/projects/1804718)
<!-- CURSEFORGE-BADGE:END -->

Download the current release of **Always Critical** for Minecraft Bedrock Edition.

## Download

- **Package format:** `.mcpack`
- **Direct download:** [Download Always Critical (.mcpack)](https://github.com/AllensCreations/MCPE-Curseforges/raw/main/builds/Always-Critical/AlwaysCritical%20V2.mcpack)

## Installation

1. Download the package using the link above.
2. Open the downloaded file with Minecraft to import it.
3. If the package contains a pack that must be enabled separately, activate it in your world's settings.

## Pack Information

For gameplay features, usage details, compatibility notes, and other project information, read the [full description](https://github.com/AllensCreations/MCPE-Curseforges/blob/main/MCPEDL/Script/Always-Critical/DESCRIPTION.md).
