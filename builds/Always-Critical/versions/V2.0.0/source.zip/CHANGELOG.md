# Changelog — Always Critical

---

## [v2] - 2026-11-14

**What's new in v1.0.0:** Packed with the v1.0.0 update. Includes: Always Critical.

### Added

- **Always Critical**: Every melee hit a player lands deals 1.5 times the normal damage, the same bonus as a vanilla critical hit, without jumping or falling first.
- **Critical Hit Sparks**: Each boosted hit shows the standard critical hit sparks on the target.

