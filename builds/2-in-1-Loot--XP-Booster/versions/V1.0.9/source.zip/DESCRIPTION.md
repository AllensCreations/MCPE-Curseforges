# 2-in-1 Loot & XP Booster — Renamed Book Menu for Loot and XP Multipliers

**By ALNStudios**

[![Minecraft Bedrock](https://img.shields.io/badge/Minecraft%20Bedrock-Stable%20Release-brightgreen?style=flat-square&logo=minecraft)](https://github.com/AllensCreations/MCPE-Curseforges)
[![Format](https://img.shields.io/badge/Format-.MCPACK%20%7C%20.MCADDON%20%7C%20.MCWORLD-blue?style=flat-square)](https://github.com/AllensCreations/MCPE-Curseforges)

**Rename a Book to Booster, then set Loot up to 32x and XP up to 64x with two sliders and an on/off switch.**

> Adds a Booster menu with a Loot slider up to 32x, an XP slider up to 64x and an on/off switch.

## Overview

You rename a Book to Booster on an anvil and right-click with it. A menu opens with three buttons: XP & Loot Booster, About and Exit.

## Showcase / Previews

### Booster Toggled On
![Booster Toggled On](https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/8f0ab1fe93e6ba15024af670baf457deb090facd/MCPEDL/Addons/2-in-1-Loot--XP-Booster/Screen_Recording_20261113_131721.gif)

### Booster Toggled Off
![Booster Toggled Off](https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/85f45452b283e0f8505fb0935610ef1fb67677e3/MCPEDL/Addons/2-in-1-Loot--XP-Booster/Screen_Recording_20261113_131753.gif)

## Key Features

### Renamed Book Control Panel
- **What Happens**: Rename a Book to "Booster" on an anvil, then right-click with it to open the Booster menu.
- **Good To Know**: Each player keeps their own settings, which are saved between sessions.

### Loot Drop Booster
- **What Happens**: Drag the Loot slider across six levels, 1x, 2x, 4x, 8x, 16x and 32x, for ores, crops and other Fortune-style blocks you break and for mobs you kill.
- **Good To Know**: Each drop rolls a random bonus up to the level you pick. It works like a Fortune and Looting bonus, but with its own random roll. Ores, ancient debris, gilded blackstone, amethyst clusters, glowstone, sea lanterns, melons, nether wart, sweet berries, wheat, carrots, potatoes, beetroot and mob loot are multiplied, so normal blocks such as dirt, stone and wood drop as usual, and unstackable items such as tools are left alone. Mining with Silk Touch drops the block once and is never multiplied. Fortune still works, and the booster multiplies on top of it.

### XP Gain Booster
- **What Happens**: Drag the XP slider across seven levels, from 1x up to 64x, and nearby XP orbs are multiplied by that exact amount.
- **Good To Know**: XP orbs within 8 blocks of you are collected instantly instead of drifting toward you.

### About Screen
- **What Happens**: The About button shows the creator, the add-on version, a short note on both packs, the CurseForge and MCPEDL profiles and an unofficial-product notice.

### Redesigned UI
- **What Happens**: A small Resource Pack named Redesigned UI gives the Booster menus the ALNStudios look, with a dark panel, a blue border, a gold title, pixel-style text and icon buttons.
- **Good To Know**: Enable the Resource Pack together with the Behavior Pack. Without it the menu text will not display correctly.

## How to Use

1. Rename a Book to Booster on an anvil.
2. Hold it and right-click, then choose XP & Loot Booster.
3. Drag the Loot and XP sliders, switch Boosters on or off, press Apply and check the Action Bar for your values.

## Common Questions

- **Does the multiplier apply to other players?**: No. Each player chooses their own Loot and XP multipliers.
- **Can I turn it off?**: Yes. Open XP & Loot Booster, switch Boosters Off and press Apply. Your levels are kept.

## Compatibility

- Minecraft Bedrock Edition: 1.26.60 minimum, taken from the release notes that introduced the required modules.
- Experimental features: No experiment requirement detected in the inspected files.
- Achievements: Likely achievement-friendly.
- Verification: Source created, not tested in game.

## Creator and Permissions

- Creator: ALNStudios
- Profiles: [CurseForge Profile](https://www.curseforge.com/members/allenscreations/projects) · [MCPEDL Profile](https://mcpedl.com/user/alnstudios/)

<a href="https://www.curseforge.com/members/allenscreations/projects"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/curseforge.jpg" alt="CurseForge" width="45%"></a> <a href="https://mcpedl.com/user/alnstudios/"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/MCPEDL.jpg" alt="MCPEDL" width="45%"></a>

## Guidelines and Attribution

- Creator: ALNStudios
- Rights & Reservation: All rights reserved for ALNStudios.
- Content Creators: Content creators are permitted to feature this creation in videos and streams with credit to ALNStudios.
- Redistribution: Do not re-upload this pack or provide direct monetized download bypasses. Link directly to the official repository page.
- Disclaimer: This is an unofficial community creation. It is not an official Minecraft product and is not approved by or associated with Mojang or Microsoft.

---

© All rights reserved for ALNStudios.

---

## Search & Discovery Keywords

Minecraft Bedrock add-on, 2-in-1 Loot & XP Booster Bedrock mod, loot multiplier, XP multiplier, renamed book menu, Minecraft PE survival, MCPEDL add-on, CurseForge Bedrock, ALNStudios.

