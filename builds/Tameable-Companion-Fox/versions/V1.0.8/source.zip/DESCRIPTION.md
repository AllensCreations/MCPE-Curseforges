# Tameable Companion Fox — Advanced Fox Companion

**By AllensCreations**

[![Minecraft Bedrock](https://img.shields.io/badge/Minecraft%20Bedrock-Stable%20Release-brightgreen?style=flat-square&logo=minecraft)](https://github.com/AllensCreations/MCPE-Curseforges)
[![Format](https://img.shields.io/badge/Format-.MCPACK%20%7C%20.MCADDON%20%7C%20.MCWORLD-blue?style=flat-square)](https://github.com/AllensCreations/MCPE-Curseforges)

Tame loyal foxes, command resting poses, and arm your companions with weapons.

---

## Overview

**Tameable Companion Fox** allows you to tame wild foxes into loyal, protective companions. Feed them sweet berries or glow berries to bond with them, command them to sit down with authentic curl-up resting animations, and even equip swords or axes directly into their mouths to turn them into powerful survival allies.

Red and arctic foxes can become companions with the same core commands and equipment options.

---

## Key Features

### Berry Taming
- **Description**: Tame wild red and arctic foxes using sweet berries or glow berries.

### Bodyguard Protection
- **Description**: Tamed foxes bravely defend you by attacking hostile mobs that target you.

### Upgraded Vitality
- **Description**: Companions receive a boosted 30 HP health pool for extra combat resilience.

### Sit & Stand Commands
- **Description**: Simply tap with an empty hand to switch between following mode and cozy resting.

### Weapon Arming
- **Description**: Hand any sword or axe to your fox to boost its attack power in combat.

### Healing Support
- **Description**: Feed berries to your companion at any time to restore its health during battle.

---

## How It Works

### Tame Fox
- **Requirement**: Sweet Berries / Glow Berries
- **What Happens**: Pacifies the wild fox and establishes a companion bond.

### Command Sit
- **Requirement**: Empty Hand (on standing fox)
- **What Happens**: Commands your fox to sit down and rest in place.

### Command Stand
- **Requirement**: Empty Hand (on sitting fox)
- **What Happens**: Fox stands up and resumes active bodyguard following.

### Equip Sword
- **Requirement**: Hold Sword & Interact
- **What Happens**: Arms your fox with the sword held in its mouth for extra damage.

### Equip Axe
- **Requirement**: Hold Axe & Interact
- **What Happens**: Arms your fox with the axe for heavy-hitting combat strikes.

### Restore Health
- **Requirement**: Feed Berries
- **What Happens**: Quickly heals your companion when damaged.

---

## Compatibility

- Minecraft Bedrock Edition 1.21.0+
- Behavior Pack & Resource Pack format

---
- Experimental features: Not verified.
- Achievements: Likely achievement-friendly.
- Verification: Source created, not tested in game.

## Creator and Permissions

- Creator: AllensCreations
- Profiles: [CurseForge Profile](https://www.curseforge.com/members/allenscreations/projects) · [MCPEDL Profile](https://mcpedl.com/user/allenscreations/)

<a href="https://www.curseforge.com/members/allenscreations/projects"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/curseforge.jpg" alt="CurseForge" width="45%"></a> <a href="https://mcpedl.com/user/allenscreations/"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/MCPEDL.jpg" alt="MCPEDL" width="45%"></a>

## Guidelines and Attribution

- Creator: AllensCreations
- Rights & Reservation: All rights reserved for AllensCreations.
- Content Creators: Content creators are permitted to feature this creation in videos and streams with credit to AllensCreations.
- Redistribution: Do not re-upload this pack or provide direct monetized download bypasses. Link directly to the official repository page.
- Disclaimer: This is an unofficial community creation. It is not an official Minecraft product and is not approved by or associated with Mojang or Microsoft.

---

© All rights reserved for AllensCreations.

---

## Search & Discovery Keywords

Tameable Companion Fox Minecraft Bedrock, Berry Taming Bedrock, Bodyguard Protection Bedrock, Upgraded Vitality Bedrock, Sit & Stand Commands Bedrock, Minecraft PE survival, MCPEDL, CurseForge Bedrock, AllensCreations, Minecraft Bedrock add-on, MCPEDL add-on.

