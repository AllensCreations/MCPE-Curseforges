# Sudden Death Roulette — The Diamond Race

**By AllensCreations**

[![Minecraft Bedrock](https://img.shields.io/badge/Minecraft%20Bedrock-Stable%20Release-brightgreen?style=flat-square&logo=minecraft)](https://github.com/AllensCreations/MCPE-Curseforges)
[![Format](https://img.shields.io/badge/Format-.MCPACK%20%7C%20.MCADDON%20%7C%20.MCWORLD-blue?style=flat-square)](https://github.com/AllensCreations/MCPE-Curseforges)

**ESCALATING SURVIVAL CHALLENGE & PERILOUS DIAMOND HUNT**

Race against an escalating, invisible death clock: find a diamond before the Grim Reaper claims your soul. Features escalating roll odds, near-miss heartbeats, three tiered audio-visual warnings, and a cinematic elimination jumpscare.

---

## Overview

**Sudden Death Roulette: The Diamond Race** transforms ordinary Minecraft survival into a high-stakes survival challenge. Engineered on the modern Minecraft Bedrock mechanics, the danger escalates until you find a Diamond.

After an initial 15-second grace period upon spawning, the roulette begins after the grace period. Surviving rolls isn't guaranteed—only by mining or acquiring a genuine diamond can a player lift the curse and secure permanent salvation.

---

## Escalating Danger Stages

### Starting Grace Period
- **Trigger & Frequency**: First 15 seconds after joining
- **Audio-Visual Warning**: Peaceful ambient chimes, initial rules toast
- **Threat Level**: Safe

### Stage 1: The Whispers
- **Trigger & Frequency**: Early roll failure
- **Audio-Visual Warning**: Faint warden heartbeat, unsettling subterranean whisper sounds
- **Threat Level**: Low

### Stage 2: The Shivers
- **Trigger & Frequency**: Moderate roll failure
- **Audio-Visual Warning**: Sudden screen darkening, shivering sound, cold dread title
- **Threat Level**: High

### Stage 3: The Toll
- **Trigger & Frequency**: Critical roll failure
- **Audio-Visual Warning**: Resonant bell toll, screeching ghast echo, final warning broadcast
- **Threat Level**: Imminent Death

### Elimination
- **Trigger & Frequency**: Lethal roulette strike
- **Audio-Visual Warning**: brief cinematic blindness jumpscare, thunder roar, instant lethal damage
- **Threat Level**: Game Over

---

## Victory Condition & Mechanics

- **The Diamond Salvation**:
  - Finding, mining, or picking up a vanilla Diamond (Diamond) immediately halts the death roulette.
  - Plays a triumphant victory fanfare, broadcasts a server-wide survival announcement, and permanently clears the reaper's curse for that player.
- **Near-Miss Feedback**:
  - If a player narrowly survives a fatal roll within the 5% margin, an audible racing heartbeat and rapid particle burst warns them of their close brush with death.
- **Multiplayer Compatible**:
  - Each player tracks their own individual roulette timer, warning tiers, and salvation status independently.

---

## Compatibility

- Minecraft Bedrock Edition: 1.21.0 or newer.
- Experimental features: Not verified.
- Achievements: Likely achievement-friendly.
- Verification: Source created, not tested in game.

## Creator and Permissions

- Creator: AllensCreations
- Profiles: [CurseForge Profile](https://www.curseforge.com/members/allenscreations/projects) · [MCPEDL Profile](https://mcpedl.com/user/allenscreations/)

<a href="https://www.curseforge.com/members/allenscreations/projects"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/curseforge.jpg" alt="CurseForge" width="45%"></a> <a href="https://mcpedl.com/user/allenscreations/"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/MCPEDL.jpg" alt="MCPEDL" width="45%"></a>

## Guidelines and Attribution

- Creator: AllensCreations
- Rights & Reservation: All rights reserved for AllensCreations.
- Content Creators: Content creators are permitted to feature this creation in videos and streams with credit to AllensCreations.
- Redistribution: Do not re-upload this pack or provide direct monetized download bypasses. Link directly to the official repository page.
- Disclaimer: This is an unofficial community creation. It is not an official Minecraft product and is not approved by or associated with Mojang or Microsoft.

---

© All rights reserved for AllensCreations.

---

## Search & Discovery Keywords

Sudden Death Roulette Minecraft Bedrock, Grace Period Bedrock, Stage 1: The Whispers Bedrock, Stage 2: The Shivers Bedrock, Stage 3: The Toll Bedrock, Minecraft PE survival, MCPEDL, CurseForge Bedrock, AllensCreations, Minecraft Bedrock add-on, MCPEDL add-on.

