# ALN ChestLog

<!-- CURSEFORGE-BADGE:START -->
[![CurseForge](https://img.shields.io/badge/CurseForge-v4-orange?style=flat-square&logo=curseforge)](https://www.curseforge.com/projects/1835099)
<!-- CURSEFORGE-BADGE:END -->

Download the current release of **ALN ChestLog** for Minecraft Bedrock Edition.

## Download

- **Package format:** `.mcaddon`
- **Direct download:** [Download ALN ChestLog (.mcaddon)](https://github.com/AllensCreations/MCPE-Curseforges/raw/main/builds/ALN-ChestLog/ALNChestLog%20V5.mcaddon)

## Installation

1. Download the package using the link above.
2. Open the downloaded file with Minecraft to import it.
3. If the package contains a pack that must be enabled separately, activate it in your world's settings.

## Pack Information

For gameplay features, usage details, compatibility notes, and other project information, read the [full description](https://github.com/AllensCreations/MCPE-Curseforges/blob/main/MCPEDL/Addons/ALN-ChestLog/DESCRIPTION.md).
