import { world, system, BlockInventoryComponent } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";
import {
  ITEM_ID,
  CONTAINER_TYPES,
  findEntry,
  saveEntry,
  deleteEntry,
  newId,
  refreshKnown,
  markSuppressed,
  showForm,
  flushEntry,
  releasePending,
} from "./chest_sync.js";

const DEFAULT_NAME = "Storage Chest";
const NEIGHBORS = [
  { x: 1, y: 0, z: 0 },
  { x: -1, y: 0, z: 0 },
  { x: 0, y: 0, z: 1 },
  { x: 0, y: 0, z: -1 },
];

function findPartner(block) {
  if (block.typeId === "minecraft:barrel") return undefined;
  const component = block.getComponent(BlockInventoryComponent.componentId);
  if (!component || !component.container || component.container.size <= 27) return undefined;
  for (const offset of NEIGHBORS) {
    const neighbor = block.offset(offset);
    if (neighbor && neighbor.typeId === block.typeId) {
      return { x: neighbor.x, y: neighbor.y, z: neighbor.z };
    }
  }
  return undefined;
}

function tell(player, text) {
  player.onScreenDisplay.setActionBar(text);
}

async function openRegisterForm(player, dimensionId, clicked) {
  const dimension = world.getDimension(dimensionId);
  const block = dimension.getBlock(clicked);
  if (!block) return;

  const existing = findEntry(dimensionId, clicked);
  if (existing && existing.owner !== player.id) {
    tell(player, "§c[ChestLog] §fThis chest is registered by another player.");
    return;
  }

  let location = { x: clicked.x, y: clicked.y, z: clicked.z };
  let partner = findPartner(block);
  if (partner && (partner.x < location.x || (partner.x === location.x && partner.z < location.z))) {
    const swap = location;
    location = partner;
    partner = swap;
  }

  const form = new ModalFormData()
    .title("§6§lRegister Chest")
    .textField("Enter Chest Name", "e.g., Ores, Building Blocks, Mob Drops", {
      defaultValue: existing ? existing.name : DEFAULT_NAME,
    });
  if (existing) form.toggle("Unregister this chest");
  form.submitButton(existing ? "Save" : "Register");
  const response = await showForm(form, player);
  if (!response || response.canceled || !response.formValues) return;

  const current = findEntry(dimensionId, clicked);
  if (current && current.owner !== player.id) return;

  if (current && response.formValues[1] === true) {
    flushEntry(current);
    releasePending(current);
    deleteEntry(current);
    tell(player, `§e[ChestLog] §f${current.name} was unregistered.`);
    return;
  }

  const typed = String(response.formValues[0] ?? "");
  const name = typed.replace(/§./g, "").trim().slice(0, 32) || DEFAULT_NAME;

  const entry = current ?? {
    id: newId(),
    owner: player.id,
    created: Date.now(),
    name,
    dimensionId,
    location,
    pendingQueue: [],
    known: [],
  };
  if (!current && partner) entry.partner = partner;
  entry.name = name;
  refreshKnown(entry);

  if (!saveEntry(entry)) {
    tell(player, "§c[ChestLog] §fCould not save the chest.");
    return;
  }

  try {
    player.playSound("random.orb");
  } catch {}
  try {
    dimension.spawnParticle("minecraft:totem_particle", {
      x: entry.location.x + 0.5,
      y: entry.location.y + 1.2,
      z: entry.location.z + 0.5,
    });
  } catch {}
  tell(player, `§a[ChestLog] §fRegistered §e${name}§f.`);
}

export function initRegister() {
  world.beforeEvents.playerInteractWithBlock.subscribe((event) => {
    const { player, block, itemStack, isFirstEvent } = event;
    if (!itemStack || itemStack.typeId !== ITEM_ID) return;
    if (!CONTAINER_TYPES.has(block.typeId)) return;
    markSuppressed(player);
    if (!player.isSneaking) return;
    event.cancel = true;
    if (!isFirstEvent) return;
    const dimensionId = block.dimension.id;
    const clicked = { x: block.x, y: block.y, z: block.z };
    system.run(() => {
      openRegisterForm(player, dimensionId, clicked).catch(() => {});
    });
  });
}
