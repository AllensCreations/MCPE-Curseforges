# Changelog — Monster Companions

---

## [v12] - 2026-11-19 - Mount Hint Text Fix

### Fixed

- **Riding hint text**: Riding a companion such as the Warden now shows a readable dismount hint instead of raw text.

## [v11] - 2026-11-19 - Primal Beast Biscuit Recipe

### Fixed

- **Primal Beast Biscuit recipe**: The recipe now loads without errors. Place Rotten Flesh and a Bone on the top row and Sweet Berries and a Honey Bottle on the bottom row of the crafting grid.

## [v10] - 2026-11-19 - Golden Beast Biscuit Recipe

### Changed

- **Golden Beast Biscuit recipe**: Craft it by placing a Primal Beast Biscuit in the middle of a crafting table and surrounding it with 8 Gold Ingots, like a Golden Carrot.

## [v9] - 2026-11-19 - Biscuit Recipe Format Fix

### Fixed

- **Biscuit recipes**: The Primal Beast Biscuit and Golden Beast Biscuit recipes now use a newer recipe format to stop loading errors.

## [v8] - 2026-11-19 - Biscuit Recipe Fix

### Fixed

- **Biscuit recipes**: The Primal Beast Biscuit and Golden Beast Biscuit recipes no longer report loading errors and are available from the start.

## [v7] - 2026-11-19 - Recipe and Hoglin Load Fixes

### Fixed

- **Biscuit recipes**: The Primal Beast Biscuit and Golden Beast Biscuit recipes now load without errors and unlock when you pick up one of their ingredients.
- **Tamed Hoglin**: The Hoglin no longer fails to load, and a tamed Hoglin that leaves the Nether still turns into a tamed Zoglin.
- **Zombie appearance**: The Zombie no longer reports a loading error in the Resource Pack.

## [v6] - 2026-11-19 - Content Log Error Fixes

### Fixed

- **Taming feedback**: Taming a mob now plays the level-up sound and shows the totem particles instead of failing to load.
- **Companion protection**: Companions are protected from damage by you and other companions, and the Behavior Pack no longer reports loading errors for it.
- **Loyal Vex**: Summoned loyal Vexes now show the totem particles without a loading error.

## [v5] - 2026-11-19 - Equal Taming Chances

### Improved & Balanced

- **Taming chances**: Every mob is now tamed with a 50% chance per Primal Beast Biscuit, including the Warden and the Wither.
- **Tamed Warden**: Melee damage is halved from 30 to 15 once tamed.
- **Taming protection**: A newly tamed Warden or Wither gets 10 seconds of Resistance.
- **Wither mount**: The rider sits higher above the Wither's heads, and the Wither flies a little faster when ridden.

## [v4] - 2026-11-19 - Warden and Wither Companions

### Added

- **Boss Subpack**: Choose Default to keep the Warden and the Wither as vanilla bosses, or With Bosses to tame them, in the Behavior Pack settings.
- **Tameable Warden**: On the With Bosses subpack, a Primal Beast Biscuit has a 10% chance to tame a Warden into a companion.
- **Tameable Wither**: On the With Bosses subpack, a Primal Beast Biscuit has a 10% chance to tame a Wither into a companion.
- **Rideable Warden**: A tamed Warden can be ridden and steered on the ground.
- **Rideable Wither**: A tamed Wither can be ridden and steered through the air.

## [v3] - 2026-11-13

**What's new in v2.0.1:** Packed with the v2.0.1 update.

### Added

- **Pink eyes**: Tamed Zombies and Skeletons now have pink eyes, so you can tell them apart from wild ones.
---

## [2.0.0] - 2026-11-08

**What's new in v2.1.0.0:** Packed with 3 updates, from v2.0.1.0 through v2.0.0.2.

### Improved & Balanced

- **Taming chances**: Every mob is now twice as likely to be tamed with each Primal Beast Biscuit, up to a 75% chance per attempt.
- **Golden Beast Biscuit**: The Regeneration it gives a companion now lasts 30 seconds instead of 5.
---

### Added

- **Rideable Breeze**: A tamed Breeze can now be ridden and steered on the ground.
- **Rideable Ghast**: A tamed Ghast can now be ridden and steered through the air.
- **Rideable Phantom**: A tamed Phantom can now be ridden and steered through the air.
---



**What's new in v2.0.0:** Rolls up the existing changelog, from v1.0.7 through v1.3.0.



## [1.0.0] - 2026-11-04

**What's new in v1.3.0:** Packed with the v1.2.14 update.

### v1.2.x (v1.2.14)

#### Improved & Balanced
- **Witch healing**: The tamed Witch now throws a visible Regeneration splash potion at you every 25 to 40 seconds. Companions standing next to you are healed too.
- **Witch splash safety**: A tamed Witch no longer throws harmful potions at enemies standing within 4 blocks of you.
- **Peaceful difficulty**: Minecraft removes all hostile mobs on Peaceful, including tamed companions, so play on Easy or higher to keep them.
---



### Added
- **Golden Beast Biscuit:** Craft one Primal Beast Biscuit with one Gold Ingot to make a Golden Beast Biscuit that fully heals an injured companion.
- **Sit and stay:** Tap a ground companion with an empty hand to make it sit and stay in place, and tap again to make it follow you.

### Fixed
- **Repeat taming:** Feeding a biscuit to a mob that is already your companion no longer counts as another taming attempt.
- **Mob count:** The documented roster now lists the 30 mobs that can actually be tamed. Vex are summoned by tamed Evokers and cannot be tamed.

### Known Limitations
- **Existing mobs:** Hostile mobs that spawned before this update cannot be tamed. Newly spawned mobs work normally.

---



### Added
- **Automatic bodyguard:** Companions now attack aggressive hostile mobs that come near you, without waiting for you to be hurt first.

### Improved & Balanced
- **Taming chances:** Taming with a Primal Beast Biscuit is now a chance instead of guaranteed. Weaker mobs are easier to tame and stronger mobs take more attempts, and each attempt uses one biscuit.
- **No health requirement:** Mobs no longer need to be weakened before you try to tame them.
- **Companion focus:** Tamed companions no longer pick players as targets.

---



## [1.13.0] - 2026-11-04

### Improved & Balanced
- **Peaceful difficulty**: Tamed companions are no longer removed from the world when the game is set to Peaceful.
- **Player safety**: Tamed companions no longer turn on players when a vanilla anger, night-time, or raid behavior triggers.

---



## [1.12.0] - 2026-11-03

### Improved & Balanced
- **Taming feedback**: The on-screen "Companion tamed!" message has been removed. Hearts still appear when a mob is tamed.

---



## [1.11.0] - 2026-11-03

### Added
- **Taming feedback**: A burst of hearts and a "Companion tamed!" message now appear when a Primal Beast Biscuit tames a mob.
- **Witch ally healing**: A tamed Witch now also throws a healing splash potion at nearby companions that are at 5 hearts or less.

---



## [1.10.0] - 2026-10-29

### Fixed
- **Floating in the world**: Fixed a bug where you floated and saw air bubbles after entering a world with the add-on.
- **Parched stats**: Parched now matches the vanilla mob: 16 HP, Weakness arrows, immune to Weakness, and no Weakness on melee hits.

---



## [1.6.0] - 2026-10-29

### Fixed
- **Witch splash safety**: A tamed Witch no longer throws poison, slowness, or weakness potions at enemies standing within 4 blocks of you.

---



## [1.5.0] - 2026-10-29

### Added
- **Witch healing**: A tamed Witch now occasionally throws a healing splash potion at you when you are hurt.

---



## [1.4.0] - 2026-10-29

### Added
- **Parched**: The new desert skeleton can now be tamed with a Primal Beast Biscuit. A tamed Parched fires Weakness arrows at enemies and does not burn in sunlight.

### Fixed
- **Witch potions**: A tamed Witch no longer throws harmful potions at you or targets you.

---



## [1.8.0] - 2026-10-19

### Fixed
- **Recipe book visibility:** The Primal Beast Biscuit recipe is now configured as always unlocked, addressing the issue where the recipe did not appear in the crafting recipe list.
- **Recipe organization:** Added a recipe category for the biscuit recipe to help Minecraft organize it consistently.

---



## [1.7.0] - 2026-10-19

### Improved & Balanced
- **Offline crafting:** The Primal Beast Biscuit recipe is included with the Behavior Pack, so players can craft biscuits during local gameplay without an internet connection after importing and enabling the add-on.
- **Recipe presentation:** Updated the crafting recipe image to use Minecraft-style visuals for a clearer, familiar recipe guide.

### Fixed
- **Biscuit crafting access:** Addressed the reported issue where the biscuit recipe was not available for offline crafting.
- **Biscuit Recipe:** One Rotten Flesh, one Bone, one Sweet Berries, and one Honey Bottle craft four Primal Beast Biscuits.
