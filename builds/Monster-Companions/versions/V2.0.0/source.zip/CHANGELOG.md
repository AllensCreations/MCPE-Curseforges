# Changelog - Monster Companions

## [2.0.0] - 2026-11-06

**What's new in v2.0.0:** Rolls up the existing changelog, from v1.0.7 through v1.3.0.

## [1.3.0] - 2026-11-04

**What's new in v1.3.0:** Packed with the v1.2.14 update.

### v1.2.x (v1.2.14)

#### Improved & Balanced
- **Witch healing**: The tamed Witch now throws a visible Regeneration splash potion at you every 25 to 40 seconds. Companions standing next to you are healed too.
- **Witch splash safety**: A tamed Witch no longer throws harmful potions at enemies standing within 4 blocks of you.
- **Peaceful difficulty**: Minecraft removes all hostile mobs on Peaceful, including tamed companions, so play on Easy or higher to keep them.
---

## [1.2.13] - 2026-11-04

### Improved & Balanced
- **Peaceful difficulty**: Tamed companions are no longer removed from the world when the game is set to Peaceful.
- **Player safety**: Tamed companions no longer turn on players when a vanilla anger, night-time, or raid behavior triggers.

---

## [1.2.12] - 2026-11-03

### Improved & Balanced
- **Taming feedback**: The on-screen "Companion tamed!" message has been removed. Hearts still appear when a mob is tamed.

---

## [1.2.11] - 2026-11-03

### Added
- **Taming feedback**: A burst of hearts and a "Companion tamed!" message now appear when a Primal Beast Biscuit tames a mob.
- **Witch ally healing**: A tamed Witch now also throws a healing splash potion at nearby companions that are at 5 hearts or less.

---

## [1.2.10] - 2026-10-29

### Fixed
- **Floating in the world**: Fixed a bug where you floated and saw air bubbles after entering a world with the add-on.
- **Parched stats**: Parched now matches the vanilla mob: 16 HP, Weakness arrows, immune to Weakness, and no Weakness on melee hits.

---

## [1.2.6] - 2026-10-29

### Fixed
- **Witch splash safety**: A tamed Witch no longer throws poison, slowness, or weakness potions at enemies standing within 4 blocks of you.

---

## [1.2.5] - 2026-10-29

### Added
- **Witch healing**: A tamed Witch now occasionally throws a healing splash potion at you when you are hurt.

---

## [1.2.4] - 2026-10-29

### Added
- **Parched**: The new desert skeleton can now be tamed with a Primal Beast Biscuit. A tamed Parched fires Weakness arrows at enemies and does not burn in sunlight.

### Fixed
- **Witch potions**: A tamed Witch no longer throws harmful potions at you or targets you.

---

## [1.2.0] - 2026-10-28

### Added
- **Golden Beast Biscuit:** Craft one Primal Beast Biscuit with one Gold Ingot to make a Golden Beast Biscuit that fully heals an injured companion.
- **Sit and stay:** Tap a ground companion with an empty hand to make it sit and stay in place, and tap again to make it follow you.

### Fixed
- **Repeat taming:** Feeding a biscuit to a mob that is already your companion no longer counts as another taming attempt.
- **Mob count:** The documented roster now lists the 30 mobs that can actually be tamed. Vex are summoned by tamed Evokers and cannot be tamed.

### Known Limitations
- **Existing mobs:** Hostile mobs that spawned before this update cannot be tamed. Newly spawned mobs work normally.

---

## [1.1.0] - 2026-10-28

### Added
- **Automatic bodyguard:** Companions now attack aggressive hostile mobs that come near you, without waiting for you to be hurt first.

### Improved & Balanced
- **Taming chances:** Taming with a Primal Beast Biscuit is now a chance instead of guaranteed. Weaker mobs are easier to tame and stronger mobs take more attempts, and each attempt uses one biscuit.
- **No health requirement:** Mobs no longer need to be weakened before you try to tame them.
- **Companion focus:** Tamed companions no longer pick players as targets.

---

## [1.0.8] - 2026-10-19

### Fixed
- **Recipe book visibility:** The Primal Beast Biscuit recipe is now configured as always unlocked, addressing the issue where the recipe did not appear in the crafting recipe list.
- **Recipe organization:** Added a recipe category for the biscuit recipe to help Minecraft organize it consistently.

---

## [1.0.7] - 2026-10-19

### Improved & Balanced
- **Offline crafting:** The Primal Beast Biscuit recipe is included with the Behavior Pack, so players can craft biscuits during local gameplay without an internet connection after importing and enabling the add-on.
- **Recipe presentation:** Updated the crafting recipe image to use Minecraft-style visuals for a clearer, familiar recipe guide.

### Fixed
- **Biscuit crafting access:** Addressed the reported issue where the biscuit recipe was not available for offline crafting.
- **Biscuit Recipe:** One Rotten Flesh, one Bone, one Sweet Berries, and one Honey Bottle craft four Primal Beast Biscuits.
