# Monster Companions

*Tameable Hostile Mobs and Mounts by AllensCreations*

**By AllensCreations**

[![Minecraft Bedrock](https://img.shields.io/badge/Minecraft%20Bedrock-Stable%20Release-brightgreen?style=flat-square&logo=minecraft)](https://github.com/AllensCreations/MCPE-Curseforges)
[![Format](https://img.shields.io/badge/Format-.MCPACK%20%7C%20.MCADDON%20%7C%20.MCWORLD-blue?style=flat-square)](https://github.com/AllensCreations/MCPE-Curseforges)

Tame 31 hostile monsters into defensive bodyguards and controllable mounts.

---

## Overview

Monster Companions is a Minecraft Bedrock add-on that enables players to pacify and tame 31 hostile mob types into defensive bodyguards and controllable mounts.

The add-on lets players tame selected hostile mobs and use supported creatures as mounts.

## Compatibility and World Settings

- Minecraft Bedrock Edition. Check the current release listing for the supported version.
- The Primal Beast Biscuit recipe is included with the downloaded add-on.
- Achievements: Likely achievement-friendly.
- Experimental features: No experiment requirement detected in the inspected files.
- Verification: Source created, not tested in game.

---

## Features and Mechanics

### Taming Chances
Taming is no longer guaranteed. Each Primal Beast Biscuit you feed a wild hostile mob gives it a chance to become your companion, and a biscuit is used up on every attempt. Weaker mobs such as Zombies, Spiders, and Slimes are the easiest to win over, while powerful mobs such as Ghasts, Iron Golems, and Ravagers take many more attempts. Mobs do not need to be wounded first, so you can try at full health.

### Automatic Bodyguard
Companions now protect you on their own. When a hostile mob that is already angry at something comes within range of you, nearby companions step in and attack it without waiting for you to be hit first. They also keep defending you when you are hurt and join any fight you start. Companions never attack you, other players, or one another.

### Sit and Stay
Tap a companion with an empty hand to make it sit and hold its position, and tap again to have it follow you. This works for ground companions that cannot be ridden. Flying companions and rideable mounts always follow you.

### Companion Squad Mechanics
- Perimeter buffer: Companions follow the player while keeping a buffer distance to prevent obstructing the player camera or mining path. If the player sprints ahead, companions teleport behind the player safely.
- Friendly-fire immunity: Companions avoid friendly-fire damage and do not target teammates.
- Peaceful difficulty: Minecraft removes hostile mobs on Peaceful, including tamed companions. Use Easy or higher.
- Player safe: Tamed companions never turn hostile toward players.
- Auto-protect: Companions defend you from nearby aggressive hostile mobs even before you are attacked.
- Visual status indicators: Tamed companions display an always-visible floating nameplate above their head. Custom name tags can be applied directly without an anvil.
- Taming feedback: Hearts confirm when a Primal Beast Biscuit tames a mob.
- In-combat healing: Feeding a wounded companion a Primal Beast Biscuit restores 10 HP (5 hearts).
- Witch healing: A tamed Witch throws a Regeneration splash potion at you every 25 to 40 seconds, which also heals companions standing next to you.
- Sunlight protection: Tamed Zombies, Skeletons, and Phantoms can wear helmets to prevent burning in direct sunlight.
- Kamikaze Creepers: Tamed Creepers will rush enemy threats that damage the player and detonate on the target as a single-use explosive bodyguard.
- Spirit Vexes: Tamed Evokers summon Spirit Vexes that attack hostiles and despawn naturally when their lifespan ends without turning on players.

### Riding Companions
Equipping a Saddle onto supported large companions enables manual mounting and direct steering:
- Mount prompt: Uses Minecraft's normal mount prompt on touch controls, controllers, and keyboard/mouse.
- Sneak-to-interact: Crouching allows players to feed, heal, lead, or rename mounts without accidentally mounting.
- Manual steering: Autonomous wandering and head-turning are disabled while mounted.
- Wall climbing: Tamed Spiders and Cave Spiders can scale vertical surfaces and cliffs while mounted.
- Supported mounts: Spider, Cave Spider, Ravager, Iron Golem, Hoglin, Zoglin, Breeze, Ghast, and Phantom.
- Flying mounts: Tamed Ghasts and Phantoms can be steered through the air while mounted.

---

## Tameable Mob Roster (31 Mobs)

### Undead
- **Supported Mobs**: Zombie, Drowned, Husk, Zombie Villager, Zombified Pigman
- **Special Abilities**: Helmet sunlight protection, melee defense

### Skeletons
- **Supported Mobs**: Skeleton, Stray, Bogged, Parched, Wither Skeleton
- **Special Abilities**: Ranged arrow support, Wither effect, Weakness arrows

### Tricky Trials
- **Supported Mobs**: Breeze
- **Special Abilities**: Wind Charge projectile launcher, rideable mount

### Nether Beasts
- **Supported Mobs**: Hoglin, Zoglin
- **Special Abilities**: High knockback, rideable war beast

### Explosives
- **Supported Mobs**: Creeper
- **Special Abilities**: Targeted single-use defensive explosion

### Arachnids
- **Supported Mobs**: Spider, Cave Spider
- **Special Abilities**: Vertical wall climbing, rideable mount

### Dimensionals
- **Supported Mobs**: Enderman
- **Special Abilities**: Teleport interception, heavy melee damage

### Piglins
- **Supported Mobs**: Piglin, Piglin Brute
- **Special Abilities**: High attack speed, battle axe sweeps

### Occult and Slimes
- **Supported Mobs**: Witch, Slime, Magma Cube
- **Special Abilities**: Lingering potion effects, crowd control

### Nether and Sky
- **Supported Mobs**: Blaze, Ghast, Phantom
- **Special Abilities**: Fireball artillery, aerial escort, flying mounts

### Illagers
- **Supported Mobs**: Ravager, Vindicator, Pillager, Evoker
- **Special Abilities**: Heavy mount, fangs, spirit vex minions

### Golems
- **Supported Mobs**: Iron Golem, Snow Golem
- **Special Abilities**: Frontline defense, rideable mount

---

## Item Specifications

### Primal Beast Biscuit

![Primal Beast Biscuit Item](https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/MCPEDL/Addons/Monster-Companions/beast_biscuit_preview.png)

### Use
- **Effect**: Gives a wild hostile mob a chance to become your companion and restores health to an injured companion.

### Healing Value
- **Specification**: 10 HP (5 Hearts)

### Stack Size
- **Specification**: 64

### Golden Beast Biscuit
- **Effect**: Fully heals an injured companion (40 HP, 20 hearts). It does not tame wild mobs.
- **Bonus**: The companion also gains Regeneration III for 30 seconds.
- **Crafting**: 1 Primal Beast Biscuit and 1 Gold Ingot make 1 Golden Beast Biscuit at a crafting table.
- **How to Use**: Feed it to an injured companion. It cannot be used to tame wild mobs.
- **Appearance**: Uses the Primal Beast Biscuit icon with an enchanted glint.
- **Stack Size**: 64

---

## Crafting Recipes

### Primal Beast Biscuit Recipe

![Crafting Recipe: Primal Beast Biscuit](https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/MCPEDL/Addons/Monster-Companions/beast_biscuit_recipe.png)

- Type: Shapeless Crafting Table Recipe
- Ingredients: 1 Rotten Flesh, 1 Bone, 1 Sweet Berries, 1 Honey Bottle
- Yield: 4x Primal Beast Biscuits
- Recipe book: The recipe is set to appear in the crafting recipe list.
- Offline crafting: The recipe is included with the add-on, so internet access is not needed during local gameplay after import.

### Golden Beast Biscuit Recipe

- Type: Shapeless Crafting Table Recipe
- Ingredients: 1 Primal Beast Biscuit, 1 Gold Ingot
- Yield: 1x Golden Beast Biscuit
- Recipe book: The recipe is set to appear in the crafting recipe list.

---

## Creator and Permissions

- Creator: AllensCreations
- Profiles: [CurseForge Profile](https://www.curseforge.com/members/allenscreations/projects) · [MCPEDL Profile](https://mcpedl.com/user/allenscreations/)

<a href="https://www.curseforge.com/members/allenscreations/projects"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/curseforge.jpg" alt="CurseForge" width="45%"></a> <a href="https://mcpedl.com/user/allenscreations/"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/MCPEDL.jpg" alt="MCPEDL" width="45%"></a>

## Guidelines and Attribution

- Creator: AllensCreations
- Rights & Reservation: All rights reserved for AllensCreations.
- Content Creators: Content creators are permitted to feature this creation in videos and streams with credit to AllensCreations.
- Redistribution: Do not re-upload this pack or provide direct monetized download bypasses. Link directly to the official repository page.
- Disclaimer: This is an unofficial community creation. It is not an official Minecraft product and is not approved by or associated with Mojang or Microsoft.

---

© All rights reserved for AllensCreations.

---

## Search & Discovery Keywords

Monster Companions Bedrock add-on, Taming chances Minecraft Bedrock, auto-protect bodyguard mobs Minecraft Bedrock, Companion Squad Mechanics Minecraft Bedrock, Mount Mechanics and Bedrock Ride UI Minecraft Bedrock, Undead Minecraft Bedrock, Minecraft PE mod, MCPEDL add-on, CurseForge Bedrock, AllensCreations, Minecraft Bedrock add-on.

