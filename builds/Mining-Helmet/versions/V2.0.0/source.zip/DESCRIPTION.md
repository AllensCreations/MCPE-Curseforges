# Mining Helmet — Dynamic Lighting Add-on

**By ALNStudios**

[![Minecraft Bedrock](https://img.shields.io/badge/Minecraft%20Bedrock-Stable%20Release-brightgreen?style=flat-square&logo=minecraft)](https://github.com/AllensCreations/MCPE-Curseforges)
[![Format](https://img.shields.io/badge/Format-.MCPACK%20%7C%20.MCADDON%20%7C%20.MCWORLD-blue?style=flat-square)](https://github.com/AllensCreations/MCPE-Curseforges)

Wearable light for cave mining and night exploration.

---

## Overview

**Mining Helmet** adds wearable headgear with moving light to Minecraft Bedrock Edition. Equipped in your head armor slot, it continuously lights up your surroundings as you walk, run, and dig, leaving both hands free for your pickaxe, weapon, or shield. By default the light follows the spot you are looking at, and a Head Light subpack keeps it above your head instead.

The helmet provides moving light while worn, and holding a Lantern or Torch can also provide handheld light.

---

## Features and Light Power Ratings

### Mining Helmet (Lantern)
- **Light Power Level**: **15**
- **Illumination Type**: High-Intensity Beam
- **Description**: Bright illumination while worn.

### Mining Helmet (Torch)
- **Light Power Level**: **10**
- **Illumination Type**: Medium Warm Glow
- **Description**: A lower-light option for early-game cave exploration.

### Handheld / Offhand Lantern
- **Light Power Level**: **15**
- **Illumination Type**: Portable Floodlight
- **Description**: Provides moving light while a standard Lantern is held in either hand.

### Handheld / Offhand Torch
- **Light Power Level**: **10**
- **Illumination Type**: Portable Torch Light
- **Description**: Provides moving light while a standard Torch is held in either hand.

---

## Equipment Specifications

### Light Power
- **Lantern Version**: Level 15 (Daylight Maximum)
- **Torch Version**: Level 10 (Warm Glow)

### Equipment Slot
- **Lantern Version**: Head Armor
- **Torch Version**: Head Armor

### Armor Defense
- **Lantern Version**: 2 Armor Points
- **Torch Version**: 2 Armor Points

### Durability
- **Lantern Version**: 165 Uses
- **Torch Version**: 165 Uses

### Repair Item
- **Lantern Version**: Gold Ingot
- **Torch Version**: Gold Ingot

### Enchantability
- **Lantern Version**: Protection, Unbreaking, Mending, Aqua Affinity, Respiration
- **Torch Version**: Protection, Unbreaking, Mending, Aqua Affinity, Respiration

---

## Crafting Recipes

### 1. Lantern Recipe (Level 15)
Combine a standard **Lantern** with a **Golden Helmet** in a crafting table to produce the Level 15 Mining Helmet.



### 2. Torch Recipe (Level 10)
Combine a standard **Torch** with a **Golden Helmet** to craft the Level 10 Mining Helmet for early survival.



---

## How to Use

1. Import the complete add-on and enable its included packs in your world settings.
2. Craft the Lantern or Torch Mining Helmet using the listed ingredients.
3. Equip the helmet in your head armor slot to carry its light with you. Holding a Lantern or Torch can also provide light.
4. The light follows your cursor by default. To keep it above your head, choose the Head Light subpack in the Behavior Pack settings.

## Compatibility

- Minecraft Bedrock Edition. Check the current package listing for the supported release range.
- Complete Add-on (.mcaddon) format

---
- Experimental features: Not verified.
- Achievements: Yes, achievement-friendly.
- Verification: Source created, not tested in game.

## Creator and Permissions

- Creator: ALNStudios
- Profiles: [CurseForge Profile](https://www.curseforge.com/members/allenscreations/projects) · [MCPEDL Profile](https://mcpedl.com/user/alnstudios/)

<a href="https://www.curseforge.com/members/allenscreations/projects"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/curseforge.jpg" alt="CurseForge" width="45%"></a> <a href="https://mcpedl.com/user/alnstudios/"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/MCPEDL.jpg" alt="MCPEDL" width="45%"></a>

## Guidelines and Attribution

- Creator: ALNStudios
- Rights & Reservation: All rights reserved for ALNStudios.
- Content Creators: Content creators are permitted to feature this creation in videos and streams with credit to ALNStudios.
- Redistribution: Do not re-upload this pack or provide direct monetized download bypasses. Link directly to the official repository page.
- Disclaimer: This is an unofficial community creation. It is not an official Minecraft product and is not approved by or associated with Mojang or Microsoft.

---

© All rights reserved for ALNStudios.

---

## Search & Discovery Keywords

Mining Helmet Bedrock add-on, Mining Helmet (Lantern) Minecraft Bedrock, Mining Helmet (Torch) Minecraft Bedrock, Handheld / Offhand Lantern Minecraft Bedrock, Handheld / Offhand Torch Minecraft Bedrock, Minecraft PE mod, MCPEDL add-on, CurseForge Bedrock, ALNStudios, Minecraft Bedrock add-on.

