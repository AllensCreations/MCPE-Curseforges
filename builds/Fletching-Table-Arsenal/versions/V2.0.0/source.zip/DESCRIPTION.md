# Fletching Table Arsenal — Tactical Arrow Workstation

**By ALNStudios**

[![Minecraft Bedrock](https://img.shields.io/badge/Minecraft%20Bedrock-Stable%20Release-brightgreen?style=flat-square&logo=minecraft)](https://github.com/AllensCreations/MCPE-Curseforges)
[![Format](https://img.shields.io/badge/Format-.MCPACK%20%7C%20.MCADDON%20%7C%20.MCWORLD-blue?style=flat-square)](https://github.com/AllensCreations/MCPE-Curseforges)

Right-click a Fletching Table to open the Fletcher's Workbench and convert ordinary Arrows into four specialized types of ammunition, using only vanilla items.

## Overview

The Fletching Table becomes a working archery station. A menu shows your current supplies and whether each conversion is ready. Every conversion turns 16 plain Arrows into 16 specialized Arrows, renamed and color-coded so they are easy to spot in your inventory.

## Key Features

### Explosive Arrows
- **What Happens**: Costs 16 Arrows and 2 Gunpowder. On impact the arrow detonates with a small blast that hurts nearby targets but does not break blocks.

### Teleportation Arrows
- **What Happens**: Costs 16 Arrows and 1 Ender Pearl. On impact the archer is teleported to where the arrow landed.

### Frost Arrows
- **What Happens**: Costs 16 Arrows and 4 Snowballs. Targets that are hit are slowed and weakened for a short time, and any fire on them is put out.

### Incendiary Arrows
- **What Happens**: Costs 16 Arrows and 1 Fire Charge. Targets that are hit are set on fire, and arrows that land on a block can ignite the open space beside it.

## How to Use

- Right-click a Fletching Table to open the Fletcher's Workbench. Sneak while right-clicking to place blocks against the table as usual.
- Pick a conversion. If you have the materials, they are removed from your inventory and the new Arrows are added. If not, a warning appears above your hotbar.
- Only plain Arrows with no custom name count toward the cost.
- Enable the Resource Pack to get the stone-style workbench screen with slot-framed icons. Without it, the menu uses the standard Minecraft form look.
- Fire the specialized Arrows from a Bow. Crossbows are not supported.
- Specialized Arrows are chosen from the first matching stack in your inventory when you start drawing the Bow.

## Compatibility

- Minecraft Bedrock Edition: minimum version not verified; the pack declares 1.21.80.
- Experimental features: No experiment requirement detected in the inspected files.
- Achievements: Yes, achievement-friendly.
- Verification: Source created, not tested in game.

## Creator and Permissions

- Creator: ALNStudios
- Profiles: [CurseForge Profile](https://www.curseforge.com/members/allenscreations/projects) · [MCPEDL Profile](https://mcpedl.com/user/alnstudios/)

<a href="https://www.curseforge.com/members/allenscreations/projects"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/curseforge.jpg" alt="CurseForge" width="45%"></a> <a href="https://mcpedl.com/user/alnstudios/"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/MCPEDL.jpg" alt="MCPEDL" width="45%"></a>

## Guidelines and Attribution

- Creator: ALNStudios
- Rights & Reservation: All rights reserved for ALNStudios.
- Content Creators: Content creators are permitted to feature this creation in videos and streams with credit to ALNStudios.
- Redistribution: Do not re-upload this pack or provide direct monetized download bypasses. Link directly to the official repository page.
- Disclaimer: This is an unofficial community creation. It is not an official Minecraft product and is not approved by or associated with Mojang or Microsoft.

---

© All rights reserved for ALNStudios.

---

## Search & Discovery Keywords

Minecraft Bedrock add-on, Fletching Table Arsenal Bedrock mod, tactical arrows, explosive arrows, teleportation arrows, frost arrows, incendiary arrows, fletching table menu, Minecraft PE survival, MCPEDL add-on, CurseForge Bedrock, ALNStudios.

