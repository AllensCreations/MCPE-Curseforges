# Changelog — Vanilla Quality of Life

---

## [v7] - 2026-11-21 - Leaf Clearing

### Added

- **Leaf Clearing**: Tree Capitator now clears the leaves of the tree it fells, and they still drop some saplings, sticks, and apples (Oak and Dark Oak only).

### Improved & Balanced

- **Auto-Switch Blocks**: Pistons, Sticky Pistons, and Observers now use a Pickaxe, Creaking Hearts and Cacti use an Axe, and Blocks of Dried Kelp use a Hoe.

## [v6] - 2026-11-21 - Tree Replanting

### Added

- **Tree Replanting**: After Tree Capitator fells a whole tree, a matching sapling is planted where the trunk stood, using one sapling from your inventory (free in Creative).

### Improved & Balanced

- **Crop Growth Setting**: The random tick speed the pack sets on first load is now listed in the description and can be turned off in the script settings.

## [v5] - 2026-11-20 - Offhand Torch, Grass, and Recipe Fixes

### Added

- **Redstone Torch Offhand**: Redstone Torches can now be held in your offhand like other torches.

### Improved & Balanced

- **Sleeping**: The add-on no longer changes how many players must sleep to skip the night.
- **Newer Game Support**: The Behavior Pack now targets the script version that ships with Minecraft 1.26.50.

### Fixed

- **Grass and Shears**: Auto-switch now also recognizes Short Grass and Tall Grass.
- **Stairs Recipes**: Stairs crafting recipes with uneven layouts now use full-width layouts, and the Bamboo Mosaic Stairs recipe file name is corrected.

## [v4] - 2026-11-20 - Script Split and Tool Fixes

### Improved & Balanced

- **Organized Scripts**: The add-on's code is now split into separate files in a lib folder, one for each feature, so it is easier to maintain. Nothing changes in game.

### Fixed

- **Auto-Switch Blocks**: Auto-switch now picks a Pickaxe for Blocks of Coal, Quartz blocks, Bone Blocks, Respawn Anchors, Conduits, and Lightning Rods, and Packed Mud no longer switches you to a shovel.
- **Fortune on Iron and Gold**: Domino Ore Miner now applies Fortune to Iron Ore and Gold Ore, including their Deepslate versions, like it already did for other ores.
- **Leaving the World**: Chain mining pause and pending tool wear are now cleared when a player leaves, so nothing carries over.

## [v4] - 2026-11-20 - Block Tool and Fortune Fixes

### Fixed

- **Auto-Switch Blocks**: Auto-switch now picks a Pickaxe for Blocks of Coal, Quartz blocks, Bone Blocks, Respawn Anchors, Conduits, and Lightning Rods, and Packed Mud no longer switches you to a shovel.
- **Fortune on Iron and Gold**: Domino Ore Miner now applies Fortune to Iron Ore and Gold Ore, including their Deepslate versions, like it already did for other ores.
- **Leaving the World**: Chain mining pause and pending tool wear are now cleared when a player leaves, so nothing carries over.

## [v3] - 2026-11-14

**What's new in v2.1.2:** Packed with the v2.1.2 update. Includes: Description Rewrite.

### Improved & Balanced

- **Clearer Description**: The listing now follows the new layout with an overview, feature cards, step-by-step instructions, common questions, and a compatibility summary.

### Fixed

- **Leash Details**: The description no longer says the Warden and Wither can be leashed, and no longer claims a fixed number of leashable mobs.
- **Creator Links**: The MCPEDL profile link and its image now appear once and point to the correct page.

## [2.1.1] - 2026-11-14

**What's new in v2.1.1:** Packed with the v2.1.1 update. Includes: Swap-Back and Chain Mining Polish.

### Added

- **Swap-Back After Mining**: A moment after you stop mining or fighting, the item that was in Slot 1 returns to its original slot instead of staying swapped.
- **Tree Size Message**: An action-bar message now tells you when a tree was too large to fell completely.

### Improved & Balanced

- **Faster Auto-Switch**: Auto-switch now waits only about a tenth of a second after a block breaks, so it keeps up with instant-break blocks.
- **Hotbar-Only Tool Search**: Auto-switch now only uses tools from your hotbar, so items in your backpack are never moved.
- **Chain Mining Experience**: Chain mining now spawns at most 10 experience orbs per chain and gives any extra experience straight to you, so far fewer orbs appear.
- **Lighter Held Light Checks**: The held-light update does less work while you carry no light item.



## [2.1.0] - 2026-11-07

**What's new in v2.0.1.0:** Packed with the v2.0.0.1 update.

### Added

- **More Held Lights**: Glowstone, Sea Lanterns, Shroomlights, and Jack o'Lanterns now light up your surroundings at Light Level 15 while you hold them.
- **Silk Touch Auto-Switch**: Hitting glass or ice now switches to a Silk Touch tool if you carry one, and bookshelves prefer a Silk Touch Axe.

### Improved & Balanced

- **Mending Preference**: When two tools are equally good for a job, auto-switch now uses the Mending tool that needs repair first.
- **Grouped Chain Drops**: Tree Capitator and Domino Ore Miner now merge their drops into full stacks within 5-block areas, so far fewer item entities appear.
- **Direct Block Breaking**: Tree Capitator and Domino Ore Miner now break blocks and place their drops directly instead of running game commands.





## [2.0.0] - 2026-11-06

**What's new in v2.0.0.0:** Packed with 2 updates, from v1.4.1 through v1.4.2.

### Removed

- **Offhand Swap Command**: The command that swapped your offhand item is removed. Use double-sneak or Sneak + Use in the air instead.
- **Personal Toggles**: The per-player toggles added in the previous update are removed. Choose how Tree Capitator and Domino Ore Miner behave for your world with the Behavior Pack's subpack settings.

### Added

- **Personal Toggles**: Each player can turn Auto-Switch, Tree Capitator, Domino Ore Miner, and Offhand Quick-Swap on or off for themselves with /scriptevent qol:toggle. Use status to see your settings and reset to turn everything back on.

### Improved & Balanced

- **Zero Durability Tools**: A tool at 0 durability now breaks only the single block you hit and no longer starts Tree Capitator or Domino Ore Miner.
- **Durability Floor**: Tree Capitator and Domino Ore Miner now use your tool down to 0 durability without breaking it, and the next use of that tool breaks it.





## [1.0.0] - 2026-11-02

**What's new in v1.4.0:** Packed with the v1.3.30 update.

### v1.3.x (v1.3.30)

#### Improved & Balanced
- **Smoother Held Light**: The light from torches and lanterns in your hands now updates every tick, so it keeps up with you while moving and jumping.
- **Auto-Switch Only While Mining**: Auto-switch now acts only while you are hitting blocks and no longer changes your tool just because you are looking at something.

#### Fixed
- **Light Flicker While Pillar Jumping**: Placing a block where your held light was no longer leaves you in the dark; the light moves back to you immediately.
- **Durability After Auto-Switch**: If auto-switch changes your tool at the same moment a tree or ore vein is chain mined, the tool you actually mined with is put back in your hand and takes the durability loss instead of the new tool.
- **Switch Delay After Breaking**: Auto-switch now waits a few ticks after any block breaks before changing your tool, so the tool you broke the block with keeps its durability loss.





## [1.29.0] - 2026-11-02

### Fixed
- **Tool Durability**: Tree Capitator and Domino Ore Miner now reliably wear down the tool you used, even if auto-switch changes your held item right afterward.
- **Mangrove Trees**: Mangrove trees with moss carpet around their roots are now felled, and breaking Muddy Mangrove Roots no longer switches you to a shovel.
- **Auto-Switch After Chain Mining**: Auto-switch now waits about two seconds after a tree or ore vein is chain mined before it can change your tool.





## [1.28.0] - 2026-11-01

### Improved & Balanced
- **Clearer Mining Presets**: The three mining presets in the pack settings now describe what they do: Sneak to Chain Mine (Default), Auto Chain Mine: Tool in Slot 1, and Chain Mining Off (Other Features On).

- **Resource Pack Included**: The Behavior Pack now requires its Resource Pack, so both are enabled together when you activate it.





## [1.27.0] - 2026-11-01

### Fixed

- **Enchanted Tool Offhand Swap**: Swapping an enchanted or damaged tool into your offhand with a torch no longer resets it, so enchantments and remaining durability are kept.





## [1.26.0] - 2026-10-29

### Improved & Balanced

- **Maintenance release**: Repackaged the pack; no gameplay changes were recorded.





## [1.3.24] — 2026-10-29

### Improved & Balanced
- **Durability Guard**: Chain mining now stops only when the tool has 0 durability left, instead of at 1.
- **Offhand Torch Placement Removed**: Torches in the offhand can no longer be placed with Sneak + Click. Offhand quick-swap and held-item light still work.

### Fixed
- **Auto-Switch With Chain Mining**: Auto-switch now pauses briefly while a tree or ore vein is being mined so the tool in hand cannot change during it.
- **Broken Tool Chain Mining**: Tree Capitator and Domino Ore Miner no longer keep breaking blocks after the tool has broken or has no durability left.





## [1.3.22] — 2026-10-28

### Improved & Balanced
- **Continuous Auto-Switch**: While you keep mining, aiming at a different kind of block, such as moving from stone to dirt, now switches to the best tool without stopping.





## [1.3.21] — 2026-10-28

### Improved & Balanced
- **Redstone Fortune**: Chain-mined Redstone Ore with Fortune now drops extra dust the way the single-block version does, instead of multiplying the whole stack.
- **Ore Experience**: Chain-mined ores now drop their normal experience as orbs when mined without Silk Touch.
- **Tree Capitator Limits**: Logs more than 8 blocks away from the broken log are ignored, so neighboring trees are far less likely to be felled together.
- **Player Build Protection**: Trees touching planks, doors, fences, glass, bricks, or storage blocks are left standing.
- **Game Rules**: Sleep skipping and the faster random tick speed are now set once when the world first loads, so you can change them afterward.

### Fixed
- **Cobweb Shears Switch**: Looking at a cobweb no longer swaps shears into your hand; the swap now happens only when you hit the cobweb.
- **Creative Mode**: Chain mining and tree felling no longer wear down tools or drop items in Creative.
- **Melon and Pumpkin Stems**: Breaking a stem with an axe no longer fells nearby trees.
- **Accidental Hand Swap**: Quickly tapping sneak while moving or in the air, such as while bridging, no longer swaps your hands.
- **Leftover Light Blocks**: Moving light blocks left behind after a crash or reload are now removed the next time the world loads.





## [1.3.17] — 2026-10-18

### Fixed
- Corrected offhand torch stack updates so placing any supported torch consumes exactly one item in Survival and Adventure modes.
- Corrected wall-mounted orientation for regular torches, Soul Torches, and Redstone Torches so they face their supporting block instead of breaking immediately.





## [1.3.15] — 2026-10-18

### Improved & Balanced
- Added Redstone Torch to offhand quick-swap and dynamic handheld lighting, using light level 7.
- Kept chain-mining durability protection aligned with the configured one-durability-point threshold.

### Fixed
- Corrected tool selection for sandstone, red sandstone, and mud-brick blocks.
- Prevented axes from qualifying as pickaxes for ore-chain mining.
- Restricted Fortune multipliers to eligible ore categories, excluding raw iron, raw gold, and ancient debris.
- Tightened tree-canopy checks to reduce false positives from blocks below the trunk and unrelated Nether canopy blocks.





## [1.3.13] — 2026-10-17

### Changed
- Standardized the available mining presets so players can choose the intended tool behavior.
- Kept the no-sneak behavior limited to Tree Capitator and Domino Ore Miner; the required tool must be held in selected hotbar slot 1.
- Removed outdated mining preset options.





## [1.3.9] — 2026-10-17

### Changed
- Simplified mining presets to three choices: No Sneak (first hotbar slot required), Both Off, and Default (Sneak Required).
- Added a No Sneak preset for Tree Capitator and Domino Ore Miner; it only activates when the required tool is held in the selected first hotbar slot.
- Kept the sneak requirement for mining in the Default preset and left other add-on features unchanged.
- Kept the included packs on the same release.





## [1.3.6] — 2026-10-17

### Fixed
- Added a **Default (All Features)** mining preset.
- Kept the default configuration enabled for both Tree Capitator and Vein Miner.





## [1.3.3] — 2026-10-17

### Added
- **Optional Mining Presets**: Added selectable Behavior Pack presets for Tree Capitator Only, Vein Miner Only, and Vanilla Mining (both disabled). The default pack keeps both features enabled. Other QoL features remain active in every preset.
- **Independent Mining Presets:** Players can choose Tree Capitator, Vein Miner, or vanilla mining behavior through the available presets.

---





## [1.3.2] — 2026-10-16

### Added & Improved
- **The Leaf Scan (Player-Placed Leaves Ignored)**: Overworld tree canopy detection now evaluates natural leaf growth. Decorative leaves harvested with shears and placed manually by players are recognized as custom decorations and completely ignored, preventing custom hedges, bushes, and decorative roof foliage from falsely triggering tree felling or getting destroyed. Only naturally grown leaves and Nether canopies validate the tree canopy.

---





## [1.3.1] — 2026-10-15

### Added
- **Mob Head Drops Balanced**: Standardized mob head drops (Zombie, Skeleton, Creeper, Piglin, Wither Skeleton, Ender Dragon, PvP Player) to a balanced 1.0% base drop chance (+0.5% per Looting level up to 2.5% max at Looting III).
- **Wandering Trader Collector Head Trades**: Adjusted head trade offering probability to a rare 2% spawn rate in collector trade pools, priced at 1 Diamond Block + 16 Emeralds per head.
- **Shulker Shell Drop Rate**: Adjusted Shulker Shell drops to 1 to 2 shells (yielding 2 to 3 with Looting enchantments).
- **Boss Leashing Immunity**: Removed leashing capability from the Warden, Wither, and Ender Dragon to maintain boss encounter integrity while preserving universal leashing on all 98 standard entities.
- **tool durability stop**: Tuned tool durability stop from 5 to 1 durability point, giving players maximum tool usage before emergency protection activates.
- **Stonecutter Woodcutter All 12 Woods**: Added full Stonecutter recipe support for Pale Oak (Logs to Planks, Slabs, Stairs, Fences, Fence Gates, and Trapdoors), completing support for all 12 wood variants in Minecraft Bedrock.

---





## [1.3.0] — 2026-10-15

This major milestone integrates **Passive Auto-Switch Tools**, **Smart Tree Capitator**, and **Domino Ore Miner** directly into the core Vanilla Quality of Life suite, creating the ultimate all-in-one survival add-on for Minecraft Bedrock.

  — Automatic tool selection whenever the player attacks or mines blocks while holding **Slot 1** (first hotbar slot).
  — Automatically equips Pickaxe (stone, ores, obsidian, terracotta), Axe (logs, wood, planks), Shovel (dirt, sand, gravel, clay), Shears (cobwebs, leaves), and Hoe.
  — Automatically equips the best melee weapon (Sword, Axe, or Mace) when attacking hostile or passive mobs.
  — Durability health scoring: Intelligently avoids selecting nearly-broken tools to preserve gear.
  — Automated cobweb shear interaction loop.

  — Sneak while chopping any tree log to fell the entire trunk and connected branches up to **128 logs** immediately.
  — **Tree Species Matching**: Ensures Oak only fells Oak and Birch only fells Birch, preventing collateral damage in dense tree farms or forests.
  — Preserves natural leaf canopies for authentic vanilla leaf decay drops (saplings, sticks, apples).

  — Sneak while mining any mineral ore to harvest the entire contiguous vein across **all 26 spatial neighbors** (faces, edges, corners) up to **64 blocks**.
  — **Mineral Category Normalization**: Groups regular and deepslate ore variants so veins crossing stone layers mine seamlessly together.
  — Full Fortune and Silk Touch support: Correctly honors Silk Touch block drops and vanilla Fortune item multipliers.

  — When holding a Torch, Soul Torch, or Redstone Torch in your offhand, simply **Sneak and Click** on any block to place it directly from your offhand onto the floor or wall.
  — Decrements offhand stack in Survival/Adventure mode (unlimited in Creative).
  — Cave-mining quality of life: keep your Pickaxe in your mainhand while placing torches without swapping items.

  — Automatically halts chain breaks when tool durability drops to **1 point remaining**.
  — Flashes an on-screen action bar warning and plays an alert sound to protect valuable enchanted tools.

### Changed
- Aligned the pack requirements to reduce missing-dependency warnings on supported game versions.

---





## [1.2.6] — 2026-10-14

### Added
- **Offhand Quick-Swap**: Double-sneak gesture or sneak+use in air to quickly swap Torches, Lanterns, Clocks, and Compasses between mainhand and offhand.

---





## [1.2.0] — 2026-10-10

### Added
- **Mob Head Trophy Drops**: 2.5% base drop chance on player kills for Zombie, Skeleton, Creeper, and Piglin heads.
- **Wandering Trader Collector Trades**: Rare head exchanges and biome flora trading.
- **Single-Player Sleep**: 1 player sleeping in a bed skips the night on multiplayer worlds and Realms.
- **Guaranteed Shulker Shells**: 2 shells guaranteed per Shulker kill.

---





## [1.1.0] — 2026-10-05

### Added
- **Stonecutter Woodcutter**: Cut all 11 wood types in the Stonecutter at fair 1:1 craft ratios (Planks, Slabs, Stairs, Fences, Gates).
- **Stackable Potions & Milk**: Potions, Splash Potions, Lingering Potions, and Milk Buckets stack up to 16 per inventory slot.

---





## [1.0.0] — 2026-09-28

### Added
- **Universal Leashing**: Support for leashing 101 mobs including Villagers, Golems, and pacified hostiles.
- **Spider Leash Locators**: Custom torso locator alignment for spiders and cave spiders.
- **Pet Friendly-Fire Immunity**: Tamed companions take zero damage from friendly sweeps, arrows, and explosions.
- **Fast Leaf Decay**: Floating leaves decay within 1 to 2 seconds after tree felling.
