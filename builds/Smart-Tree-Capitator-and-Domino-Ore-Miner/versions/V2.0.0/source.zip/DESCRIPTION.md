# Smart Tree Capitator and Domino Ore Miner — Vein and Tree Miner

**By ALNStudios**

[![Minecraft Bedrock](https://img.shields.io/badge/Minecraft%20Bedrock-Stable%20Release-brightgreen?style=flat-square&logo=minecraft)](https://github.com/AllensCreations/MCPE-Curseforges)
[![Format](https://img.shields.io/badge/Format-.MCPACK%20%7C%20.MCADDON%20%7C%20.MCWORLD-blue?style=flat-square)](https://github.com/AllensCreations/MCPE-Curseforges)

**SNEAK-ACTIVATED VEIN MINING & BUILT-IN TOOL PROTECTION**

Fell entire trees and mine contiguous ore veins in a single sneak-break, protected by automated durability safety stops.

---

## Overview

Mining large underground ore clusters and chopping tall trees one block at a time can take time. **Smart Tree Capitator & Domino Ore Miner** adds sneak-activated chain mining to Minecraft Bedrock Edition . Sneak while breaking a log or ore to fell the entire tree or harvest the connected ore vein in one action.

## Key Features

### Sneak-Activated Mining

### Connected Tree Felling

### Connected Ore Mining

### Mineral Category Normalization

### Durability Safety Guard

### Unbreaking Respect

### Fortune & Silk Touch Support

### Zero Hunger Penalties

## How It Works

### Standard Mining
- **Requirement**: Standing or walking
- **What Happens**: Breaks single block with standard vanilla drops.

### Tree Capitation
- **Requirement**: Sneak with an Axe
- **What Happens**: Fells connected trunk logs and branches upward up to 128 blocks during the same mining action.

### Domino Ore Mining
- **Requirement**: Sneak with a Pickaxe
- **What Happens**: Sweeps contiguous ore veins across 26 spatial neighbors up to 64 blocks.

### Durability Protection
- **Requirement**: Tool has 5 durability points remaining
- **What Happens**: Halts chain break immediately, preserves tool, and plays alert sound.

### Tool Switch Safety
- **Requirement**: Switch or unequip tool
- **What Happens**: Terminates chain process instantly before processing the next block.

---

## How Tree Felling Works

When you break an eligible log while sneaking with an axe, the add-on scans through the tree:

1. **Connected Branches**: Follows connected logs and branches, including diagonal connections.
2. **Matching Wood Types**: Only the same wood type is felled, helping protect nearby trees.
3. **The Leaf Scan (Player-Placed Leaves Ignored)**: Ignores player-placed leaves (sheared decorative leaves), ensuring custom hedges, bushes, and decorative roof foliage are never falsely detected as natural tree canopies.
4. **Build Protection**: Uses nearby natural canopy clues to reduce accidental damage to wooden builds.
5. **Safety Limits**: Capped at 128 logs per tree and bounded by the world height range to prevent runaway chain reactions.

### Supported Trees
- **Overworld**: Oak, Spruce, Birch, Jungle, Acacia, Dark Oak, Mangrove (including roots), Cherry, and Pale Oak.
- **Nether**: Crimson Stem, Warped Stem, Crimson Hyphae, Warped Hyphae.
- **Wood Variants**: All stripped logs and all 6-sided bark wood blocks.
- **Canopy Leaves**: Left intact for natural leaf decay so saplings, sticks, and apples drop normally over time.

---

## How Ore Mining Works

Domino Ore Miner follows connected matching ores, including diagonal connections, up to the 64-block cluster limit. Regular and deepslate versions of the same ore can be mined together:

### Coal
- **Minimum Pickaxe**: Wooden+
- **Drops**: Coal

### Iron
- **Minimum Pickaxe**: Stone+
- **Drops**: Raw Iron

### Copper
- **Minimum Pickaxe**: Stone+
- **Drops**: Raw Copper (2–5)

### Gold
- **Minimum Pickaxe**: Iron+
- **Drops**: Raw Gold

### Nether Gold
- **Minimum Pickaxe**: Wooden+
- **Drops**: Gold Nuggets (2–6)

### Lapis Lazuli
- **Minimum Pickaxe**: Stone+
- **Drops**: Lapis Lazuli (4–9)

### Redstone
- **Minimum Pickaxe**: Iron+
- **Drops**: Redstone Dust (4–5)

### Diamond
- **Minimum Pickaxe**: Iron+
- **Drops**: Diamond

### Emerald
- **Minimum Pickaxe**: Iron+
- **Drops**: Emerald

### Nether Quartz
- **Minimum Pickaxe**: Wooden+
- **Drops**: Nether Quartz

### Ancient Debris
- **Minimum Pickaxe**: Diamond+
- **Drops**: Ancient Debris Block

*Only blocks of the same mineral category are traversed. Pickaxe tier validation ensures lower-tier tools will not trigger higher-tier ore chains.*

---

## Durability Protection System

- Checks the tool's remaining durability before breaking each additional block.
- Halts immediately when remaining durability  reaches 5 or less.
- Plays an audible warning sound (warning sound) and displays an action bar alert:
  > **[Tool Protection]** Stopped mining to save tool! (5 durability left)
- Revalidates the equipped tool before each block break. If the tool is switched or removed, chain mining stops instantly.
- Respects the normal durability-saving effect of the Unbreaking enchantment.

---

## Default Settings

### Tree Capitator
- **Default Value**: Enabled
- **Description**: Fells connected trunks and branches up to 128 logs

### Domino Ore Miner
- **Default Value**: Enabled
- **Description**: Mines connected ore clusters up to 64 blocks

### Mining Speed
- **Default Value**: Instant Burst
- **Description**: Mines the full vein or tree in a single stroke

### Durability Safety Stop
- **Default Value**: 5 Durability
- **Description**: Halts automatically to protect rare tools from breaking

### Alert Audio
- **Default Value**: Bass Note
- **Description**: Plays an alert sound when safety stop activates

---

## Compatibility

- Minecraft Bedrock Edition 1.21.0+
- Experimental features: Check the current release instructions and world settings.
- Pure Behavior Pack format (.mcpack and .mcaddon)
- Multiplayer behavior should be checked in the target game version.

---
- Achievements: Likely achievement-friendly.
- Verification: Source created, not tested in game.

## Creator and Permissions

- Creator: ALNStudios
- Profiles: [CurseForge Profile](https://www.curseforge.com/members/allenscreations/projects) · [MCPEDL Profile](https://mcpedl.com/user/alnstudios/)

<a href="https://www.curseforge.com/members/allenscreations/projects"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/curseforge.jpg" alt="CurseForge" width="45%"></a> <a href="https://mcpedl.com/user/alnstudios/"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/MCPEDL.jpg" alt="MCPEDL" width="45%"></a>

## Guidelines and Attribution

- Creator: ALNStudios
- Rights & Reservation: All rights reserved for ALNStudios.
- Content Creators: Content creators are permitted to feature this creation in videos and streams with credit to ALNStudios.
- Redistribution: Do not re-upload this pack or provide direct monetized download bypasses. Link directly to the official repository page.
- Disclaimer: This is an unofficial community creation. It is not an official Minecraft product and is not approved by or associated with Mojang or Microsoft.

---

© All rights reserved for ALNStudios.

---

## Search & Discovery Keywords

Smart Tree Capitator and Domino Ore Miner Bedrock add-on, Sneak Minecraft Bedrock, Mineral Category Normalization Minecraft Bedrock, Durability Safety Guard Minecraft Bedrock, Unbreaking Respect Minecraft Bedrock, Minecraft PE mod, MCPEDL add-on, CurseForge Bedrock, ALNStudios, Minecraft Bedrock add-on.

