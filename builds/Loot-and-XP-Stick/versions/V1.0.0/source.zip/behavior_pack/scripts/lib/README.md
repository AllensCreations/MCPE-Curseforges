# Loot and XP Stick: script notes (scripts/lib)

For the AI review. Keep this file in step with the scripts: update it whenever a file in `scripts/` changes.
Extracted from the script files; nothing here was run in game.

## Files

| File | Lines | Purpose |
| :-- | --: | :-- |
| `scripts/main.js` | 230 | (no header comment) |

## Imports

- `@minecraft/server` (in `main.js`)
- `@minecraft/server-ui` (in `main.js`)

## Events

- `world.afterEvents.entityDie`
- `world.afterEvents.entitySpawn`
- `world.afterEvents.playerBreakBlock`
- `world.beforeEvents.itemUse`

## Custom ids

- none found
- plus 16 vanilla `minecraft:` id(s)

## Features found

- ModalFormData
- delayed task (system.runTimeout)
- dynamic properties (saved data)
- repeating timer (system.runInterval)

## Notes (AI review)

Known limits, design decisions and things to check on the next update go here. Not filled in yet.
