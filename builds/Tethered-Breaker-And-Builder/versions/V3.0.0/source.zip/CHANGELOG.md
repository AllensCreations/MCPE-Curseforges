# Changelog — Tethered: Breaker and Builder

---

## [v3] - 2026-11-20 - Leash Limit

### Improved & Balanced
- **Rope limit**: The tether is now 10 meters long. Partners can no longer get farther apart than that, including straight up or down, so building or flying away from your partner pulls you back.
- **Tension**: You feel tension from 6 meters and are pulled toward your partner beyond 8 meters. The pull now works up and down as well. Strain damage starts beyond 9 meters.
- **Leash look**: The beam is now a brown leash-style line that keeps the same color at every distance. The on-screen display still shows the four distance states.
- **Own beam particle**: The beam no longer uses the built-in flame, spark and happy particles, so it needs no extra particle variables.

## [2.0.1] - 2026-11-20 - Test Dummy

### Added
- **Test Dummy**: The Controller has a new Spawn Test Dummy option for testing alone. It places a stand-in partner next to you that you are leashed to once you pick a role. Removing it, or ending the challenge, takes it away. A real partner who picks the other role replaces it.

## [v2] - 2026-11-14

**What's new in v1.12.1:** Packed with the v1.12.1 update. Includes: Performance and Stability.

### Added

- **Waiting for partner**: If your partner leaves or has not chosen a role yet, the screen says you are waiting and the leash timers pause.
- **Role menu protection**: Players are protected for five seconds while the role menu is open.

### Improved & Balanced

- **Smoother gameplay**: The leash, restrictions and on-screen display do far less work, which cuts lag, especially on phones and busy worlds.
- **Lighter beam**: The leash beam is drawn less often with fewer particles, and is hidden when partners are very close.
- **Steadier on-screen display**: The leash distance is shown in half-meter steps and only refreshes when it changes.
- **No cost between games**: The pack does no leash work until a challenge is started and stops when it ends.

### Fixed

- **Restriction messages**: Messages explaining blocked actions now appear right away, even before both roles are chosen.
- **Controller after respawn**: The host or an operator gets the Controller back after respawning when no challenge is running.

## [1.12.0] - 2026-10-29

### Improved & Balanced

- **Maintenance release**: Repackaged the pack; no gameplay changes were recorded.



## [1.7.0] - 2026-10-27

### Added
- **Controller**: The host or an operator starts the challenge from the ALNStudios Controller. Roles and the leash are active only while the challenge is running.
- **Win condition**: Defeating the Ender Dragon ends the challenge.
- **Recall**: Partners who stay more than 64 blocks apart, or in different dimensions, are brought together.

### Improved & Balanced
- **Role choice**: Each role can be held by one player. Players without a role cannot build, mine or fight, and are asked again until they choose.
- **Breaker limits**: Spawn eggs, boats, minecarts, armor stands, item frames, paintings, end crystals and bone meal are now blocked along with buckets and fire. Anything placed anyway is removed and returned.
- **Builder limits**: Builders can no longer hurt anything with bows, tridents or thrown items, or set off TNT.
- **Gentler leash**: The pull is weaker and stays horizontal. Strain damage starts after 3 seconds and never takes you below one heart. Creative and spectator players are not pulled.

### Fixed
- **Pack failed to work**: The pack stopped working after the role menu in current versions of Minecraft. The leash, restrictions and respawn support now work.
- **Role cheating**: Closing the role menu no longer removes restrictions, and roles cannot be changed with the tag command.
- **Lag from distant partners**: Very distant partners no longer cause lag from beam particles.
- **Joining**: Joining the world no longer teleports you to your partner.
- **Restriction messages**: Messages explaining blocked actions now stay on screen.
- **Description**: Removed the claim that the Builder has exclusive crafting.
