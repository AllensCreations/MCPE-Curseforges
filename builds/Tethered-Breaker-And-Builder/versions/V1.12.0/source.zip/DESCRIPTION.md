# Tethered: Breaker and Builder — Two-Player Co-op Challenge

**By ALNStudios**

[![Minecraft Bedrock](https://img.shields.io/badge/Minecraft%20Bedrock-Stable%20Release-brightgreen?style=flat-square&logo=minecraft)](https://github.com/AllensCreations/MCPE-Curseforges)
[![Format](https://img.shields.io/badge/Format-.MCPACK%20%7C%20.MCADDON%20%7C%20.MCWORLD-blue?style=flat-square)](https://github.com/AllensCreations/MCPE-Curseforges)

Work together as a mining-and-combat partner and a building specialist while an elastic tether keeps you close. Tethered: Breaker and Builder divides survival abilities between two players, making teamwork essential.

## Overview

Two players share a 15-meter tether. The Breaker handles mining and combat but cannot place blocks or fluids. The Builder can construct and place fluids but cannot mine blocks or attack. Stretching too far pulls partners back together, and severe overextension causes non-lethal damage. Defeat the Ender Dragon together to win.

## Key Features

### Asymmetric Roles
- **What Happens**: Each player chooses Breaker or Builder when the challenge starts. Each role can be held by one player.

### Elastic Tether
- **What Happens**: Partners are pulled toward each other beyond 15 meters, with strain damage beyond 18 meters after a short grace period.

### Tension Feedback
- **What Happens**: A particle beam, sound cues and an on-screen display show four distance states: slack, tense, overstretched and strained.

### Recall
- **What Happens**: Partners who are very far apart or in different dimensions for too long are brought back together.

### Respawn Support
- **What Happens**: A partner who dies respawns beside the survivor with temporary protection.

### Controller
- **What Happens**: The host or an operator uses the ALNStudios Controller to start the challenge and read the rules.

## How to Use

1. Import and enable the pack in a Minecraft Bedrock world.
2. The host or an operator uses the Controller and chooses Start.
3. Each player picks a role from the menu.
4. The Breaker gathers and defends while the Builder constructs. Stay within the leash range.
5. Defeat the Ender Dragon to win.

## Compatibility

- Minecraft Bedrock Edition: 1.26.40 or newer
- Experimental features: No experiment requirement detected in the inspected files.
- Achievements: Likely achievement-friendly. Operator commands require cheats, which disables achievements.
- Verification: Source created, not tested in game.

## Creator and Permissions

- [CurseForge Profile](https://www.curseforge.com/members/allenscreations/projects)
- [MCPEDL Profile](https://mcpedl.com/user/allenscreations/)

<a href="https://www.curseforge.com/members/allenscreations/projects"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/curseforge.jpg" alt="CurseForge" width="45%"></a> <a href="https://mcpedl.com/user/allenscreations/"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/MCPEDL.jpg" alt="MCPEDL" width="45%"></a>

## Guidelines and Attribution

- Creator: ALNStudios
- Rights & Reservation: All rights reserved for ALNStudios.
- Content Creators: Content creators are permitted to feature this creation in videos and streams with credit to ALNStudios.
- Redistribution: Do not re-upload this pack or provide direct monetized download bypasses. Link directly to the official repository page.
- Disclaimer: This is an unofficial community creation. It is not an official Minecraft product and is not approved by or associated with Mojang or Microsoft.

---

© All rights reserved for ALNStudios.

---

## Search & Discovery Keywords

Minecraft Bedrock co-op challenge, Tethered Breaker and Builder, asymmetric two-player survival, Minecraft tether, cooperative mining and building, multiplayer survival minigame, Minecraft PE challenge, MCPEDL, CurseForge Bedrock, ALNStudios, Minecraft Bedrock add-on, MCPEDL add-on.

