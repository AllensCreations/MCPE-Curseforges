# Changelog — Living SMP Chat

---

## [1.0.1] - 2026-11-15 - Spawner Tips

### Added
- **Spawner Tips**: once in a while a virtual player tells you the real position of a Monster Spawner close to you, usually a dungeon, and a second player replies. About one in three tips drops a minus sign and is corrected by the same player about two minutes later. Each spawner is announced only once, and nothing is said when none is nearby.

## [1.0.0] - 2026-11-15

**What's new in v1.0.0:** Packed with the v1.0.0 update. Includes: Living SMP Chat.

### Added

- **Virtual SMP Roster**: 18 virtual players in five personality types (Builder, Redstoner, PvPer, Wholesome, Chaotic). Between 5 and 10 are online at a time and they join and leave with the usual yellow messages.
- **Death Reactions**: when you die to a creeper, lava, a fall, the void, a mob or anything else, two to four virtual players react and offer to help.
- **Ore Celebrations**: mining Diamond Ore, Deepslate Diamond Ore or Ancient Debris starts one celebration chat per vein instead of one per block.
- **Welcome Back, Sleep and Travel Chat**: virtual players greet you when you join and comment when you sleep or enter the Nether or the End.
- **Ambient SMP Banter**: every 1.5 to 3 minutes the server chat fills with 2 to 5 message conversations about videos, builds, lag and small PvP dramas.

