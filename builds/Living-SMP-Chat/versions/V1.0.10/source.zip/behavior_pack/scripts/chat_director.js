import { world, system } from "@minecraft/server";
import { ROSTER, formatChat, isOnline, pickOnline } from "./smp_roster.js";
import { REAL_NAMES } from "./smp_voices.js";
import { assembleMessage, pickItem, renderLine } from "./chat_generator.js";
import { DIALOGS } from "./chat_lines_extra.js";
import { WORLD_CHANGES, CHAT_PACE } from "./mode.js";

const MIN_DELAY = 35;
const MAX_DELAY = 100;
const GAP_BETWEEN_CONVERSATIONS = 80;
const MAX_QUEUE = 4;

const queue = [];
let busy = false;

const rand = (a, b) => a + Math.floor(Math.random() * (b - a + 1));

function runNext() {
  if (busy || queue.length === 0) return;
  const lines = queue.shift();
  busy = true;
  let t = rand(20, 50);
  for (const line of lines) {
    system.runTimeout(() => {

      if (line.run) {
        line.run();
        return;
      }
      if (line.bot && !isOnline(line.bot)) return;
      world.sendMessage(line.bot ? formatChat(line.bot, line.text) : line.text);
    }, t);
    t += rand(MIN_DELAY, MAX_DELAY);
  }
  system.runTimeout(() => {
    busy = false;
    runNext();
  }, t + GAP_BETWEEN_CONVERSATIONS);
}

export function playConversation(linesArray, options = {}) {
  const lines = (linesArray || []).filter((l) => l && (l.text || l.run));
  if (lines.length === 0) return false;
  if (options.priority) queue.unshift(lines);
  else if (busy || queue.length > 0) return false;
  else queue.push(lines);
  while (queue.length > MAX_QUEUE) queue.pop();
  runNext();
  return true;
}

function chain(bots, categories, ctx) {
  return bots.map((bot, i) => ({
    bot,
    text: assembleMessage(categories[Math.min(i, categories.length - 1)], { ...ctx, speaker: bot }),
  }));
}

export function reactToDeath(player, kind, cause, hint) {
  const n = rand(2, 4);
  const bots = pickOnline(n);
  if (bots.length < 2) return;
  const first = `death_${kind}`;
  const cats = [first, "death_followup", "support_reply", "death_followup"];
  playConversation(chain(bots, cats, { player, cause, coordHint: hint }), { priority: true });
}

export function reactToOre(player, oreKind, count, hint) {
  const bots = pickOnline(count >= 4 ? 3 : 2);
  if (bots.length < 2) return;
  const item = pickItem(oreKind);
  const cats = [`ore_${oreKind}`, "ore_reply", "support_reply"];
  const lines = chain(bots, cats, { player, item, coordHint: hint });
  playConversation(lines, { priority: true });
}

export function welcomeBack(player) {
  const bots = pickOnline(rand(2, 3));
  if (bots.length < 2) return;
  playConversation(chain(bots, ["greeting_wb", "greeting_hello", "greeting_anyone"], { player }), { priority: true });
}

export function reactToEvent(player, category) {
  const bots = pickOnline(2);
  if (bots.length < 2) return;
  playConversation(chain(bots, [category, "support_reply"], { player }), { priority: true });
}

function dramaChain() {
  const bots = pickOnline(3);
  if (bots.length < 3) return false;
  const [a, b, c] = bots;
  const ctx = { botA: a.name, botB: b.name };
  return playConversation([
    { bot: a, text: assembleMessage("drama_kill", { ...ctx, speaker: a }) },
    { bot: b, text: assembleMessage("drama_complain", { ...ctx, speaker: b }) },
    { bot: c, text: assembleMessage("drama_laugh", { ...ctx, speaker: c }) },
  ]);
}

const VANILLA_DEATHS = [
  { kind: "creeper", cause: "a creeper", msg: "was blown up by Creeper" },
  { kind: "mob", cause: "a zombie", msg: "was slain by Zombie" },
  { kind: "mob", cause: "a skeleton", msg: "was shot by Skeleton" },
  { kind: "mob", cause: "a spider", msg: "was slain by Spider" },
  { kind: "lava", cause: "lava", msg: "tried to swim in lava" },
  { kind: "fall", cause: "fall damage", msg: "hit the ground too hard" },
  { kind: "void", cause: "the void", msg: "fell out of the world" },
  { kind: "generic", cause: "something", msg: "drowned" },
  { kind: "generic", cause: "something", msg: "burned to death" },
];

function skipNight() {
  try {
    const timeOfDay = world.getTimeOfDay();
    if (timeOfDay < 12500 || timeOfDay >= 23000) return;
    world.setAbsoluteTime(world.getAbsoluteTime() + (24000 - timeOfDay));
  } catch (e) {
    return;
  }
  try {
    world.getDimension("overworld").setWeather("Clear");
  } catch (e) {}
  world.sendMessage("§7Sleeping through this night");
  system.runTimeout(() => {
    const bot = pickOnline(1)[0];
    if (bot) world.sendMessage(formatChat(bot, assembleMessage("bot_wake", { speaker: bot })));
  }, rand(40, 100));
}

export function botSleeps() {
  const bots = pickOnline(rand(2, 3));
  if (bots.length < 2) return;
  const lines = chain(bots, ["bot_sleep", "bot_sleep_reply", "bot_sleep_reply"], {});
  if (WORLD_CHANGES) lines.push({ run: skipNight });
  playConversation(lines, { priority: true });
}

function botDeath() {
  const bots = pickOnline(3);
  if (bots.length < 2) return;
  const victim = bots[0];
  const d = VANILLA_DEATHS[rand(0, VANILLA_DEATHS.length - 1)];
  const lines = [{ text: victim.name + " " + d.msg }];
  lines.push({ bot: bots[1], text: assembleMessage("death_" + d.kind, { player: victim.name, cause: d.cause, speaker: bots[1] }) });
  lines.push({ bot: victim, text: assembleMessage("bot_death_self", { speaker: victim }) });
  if (bots[2]) lines.push({ bot: bots[2], text: assembleMessage("death_followup", { speaker: bots[2] }) });
  playConversation(lines);
}

let lastReplyTick = -1000;
let lastBrandTick = -100000;

export function replyToChat(sender, message) {
  const text = String(message || "").trim();
  if (!text || text.startsWith("/") || text.length > 200) return;
  const lower = text.toLowerCase();
  const now = system.currentTick;
  const mentioned = ROSTER.find((b) => isOnline(b) && lower.includes(b.name.toLowerCase()));
  let category = null;
  if (mentioned) category = "chat_mention";
  else if (/\b(gn|good ?night|nighty|night night)\b/.test(lower)) category = "chat_gn";
  else if (/\b(thanks|thank you|thx|ty)\b/.test(lower)) category = "chat_thanks";
  else if (/\b(hi|hello|hey|yo|sup|hallo|hola|morning|gm|wb)\b/.test(lower)) category = "chat_hi";
  else if (/\b(lol|lmao|haha|xd)\b/.test(lower)) category = "chat_laugh";
  else if (lower.includes("?")) category = "chat_question";
  else if (Math.random() < 0.2 / CHAT_PACE) category = "chat_react";
  if (!category) return;
  if (!mentioned && now - lastReplyTick < 300 * CHAT_PACE) return;
  if (category === "chat_question" && Math.random() > 0.6 / CHAT_PACE) return;
  const bots = mentioned ? [mentioned] : pickOnline(rand(1, 2));
  if (bots.length === 0) return;
  lastReplyTick = now;
  const lines = bots.map((bot, i) => ({
    bot,
    text: assembleMessage(i === 0 ? category : "support_reply", { player: sender, speaker: bot }),
  }));
  system.runTimeout(() => playConversation(lines, { priority: true }), rand(30, 90));
}

function brandChat() {
  const now = system.currentTick;
  if (now - lastBrandTick < 24000) return;
  const bots = pickOnline(2);
  if (bots.length < 2) return;
  const lines = [
    { bot: bots[0], text: assembleMessage("brand_plug", { speaker: bots[0] }) },
    { bot: bots[1], text: assembleMessage("brand_reply", { speaker: bots[1] }) },
  ];
  if (playConversation(lines)) lastBrandTick = now;
}

function slipChat() {
  const bots = pickOnline(2);
  if (bots.length < 2) return;
  const realName = REAL_NAMES[bots[0].name];
  if (!realName) return;
  const ctx = { botA: bots[0].name, realName };
  playConversation([
    { bot: bots[0], text: assembleMessage("slip", { ...ctx, speaker: bots[0] }) },
    { bot: bots[1], text: assembleMessage("slip_reply", { ...ctx, speaker: bots[1] }) },
    { bot: bots[0], text: assembleMessage("slip_end", { ...ctx, speaker: bots[0] }) },
  ]);
}

const TOPICS = [
  "weather_rain", "weather_storm", "night_falls", "morning", "farm_talk", "trade_talk", "raid_talk", "base_tour",
  "redstone_talk", "pvp_talk", "boss_dragon", "boss_wither", "nether_roof", "fishing", "explore", "pets",
  "horses_boats", "food_talk", "music_talk", "server_event", "building_progress", "lost_items", "mining_talk", "enchant_talk",
];

function topicChat(player) {
  const topic = TOPICS[rand(0, TOPICS.length - 1)];
  const bots = pickOnline(rand(2, 4));
  if (bots.length < 2) return;
  playConversation(chain(bots, [topic, topic, "support_reply", topic], { player }));
}

function dialogChat(player) {
  const script = DIALOGS[rand(0, DIALOGS.length - 1)];
  const need = Math.min(3, script.reduce((m, l) => Math.max(m, l[0] + 1), 1));
  const bots = pickOnline(need);
  if (bots.length < need) return;
  const ctx = {
    player,
    botA: bots[0].name,
    botB: bots[1] ? bots[1].name : "",
    botC: bots[2] ? bots[2].name : "",
  };
  playConversation(script.map(([i, text]) => ({ bot: bots[i], text: renderLine(text, { ...ctx, speaker: bots[i] }) })));
}

export function ambientConversation() {
  const players = world.getAllPlayers();
  if (players.length === 0) return;
  const player = players[rand(0, players.length - 1)].name;
  const roll = Math.random();
  if (roll < 0.03) return void brandChat();
  if (roll < 0.06) return void slipChat();
  if (roll < 0.11) return void botDeath();
  if (roll < 0.2) return void dramaChain();
  if (roll < 0.42) return void dialogChat(player);
  if (roll < 0.7) return void topicChat(player);
  const cats = roll < 0.8
    ? ["banter_video", "banter_video", "support_reply", "banter_video", "support_reply"]
    : roll < 0.9
      ? ["banter_build", "banter_build", "support_reply", "banter_build"]
      : roll < 0.95
        ? ["banter_video", "support_reply", "banter_build"]
        : ["greeting_anyone", "greeting_hello", "support_reply"];
  const n = Math.min(cats.length, rand(2, 5));
  const bots = pickOnline(n);
  if (bots.length < 2) return;
  playConversation(chain(bots, cats, { player }));
}
