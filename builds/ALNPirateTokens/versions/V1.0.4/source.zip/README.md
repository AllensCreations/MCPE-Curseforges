# ALNPirateTokens

<!-- CURSEFORGE-BADGE:START -->
[![CurseForge](https://img.shields.io/badge/CurseForge-v1.0.4-orange?style=flat-square&logo=curseforge)](https://www.curseforge.com/projects/1824277)
<!-- CURSEFORGE-BADGE:END -->

Download the current release of **ALNPirateTokens** for Minecraft Bedrock Edition.

## Download

- **Package format:** `.mcaddon`
- **Direct download:** [Download ALNPirateTokens (.mcaddon)](https://github.com/AllensCreations/MCPE-Curseforges/raw/main/builds/ALNPirateTokens/ALNPirateTokens%20V1.0.4.mcaddon)

## Installation

1. Download the package using the link above.
2. Open the downloaded file with Minecraft to import it.
3. If the package contains a pack that must be enabled separately, activate it in your world's settings.

## Pack Information

For gameplay features, usage details, compatibility notes, and other project information, read the [full description](https://github.com/AllensCreations/MCPE-Curseforges/blob/main/MCPEDL/Addons/ALNPirateTokens/DESCRIPTION.md).
