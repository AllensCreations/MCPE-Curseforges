# Changelog — Universal Leash

---

## [v3] - 2026-11-10

**What's new in v2.0.0.0:** Packed with the v1.0.2 update.

### Fixed

- **Spider Lead Height**: The lead on Spiders and Cave Spiders now attaches at the middle of their hitbox, about 0.45 and 0.25 blocks above the ground.

## [1.1.0] - 2026-11-10

### Fixed
- **Leashed Mobs Stay Calm**: Hostile and neutral mobs on a lead no longer fight back when you attack them.
- **Spider Lead Position**: The lead on Spiders and Cave Spiders now attaches at the center of the body instead of above it.

## [1.0.0] - 2026-11-10

### Added
- **Universal Leashing**: Leads can be attached to 98 entity types, including Villagers, Iron Golems, Zombies, Creepers, and Endermen.
- **Hostile Mobs on a Lead**: Hostile mobs on a lead stop choosing new targets.
- **Spider Lead Position**: Leads attach to the body of Spiders and Cave Spiders.
