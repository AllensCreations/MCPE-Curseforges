# Changelog — Alphabet Scavenger Hunt

---

## [v2] - 2026-11-14

**What's new in v1.9.1:** Packed with the v1.9.1 update. Includes: Victory Celebration.

### Added

- **Victory Celebration**: Finishing all 20 rounds now shows a Congratulations title and a fireworks display, then the Controller comes back so you can play again.

### Improved & Balanced

- **Smoother Performance**: The challenge now updates once per second instead of every tick, which greatly reduces lag.
- **Co-op Eliminations**: A player who dies is eliminated, and the challenge only ends when every player is out.
- **Fair Matching**: Renaming an item in an anvil no longer counts toward a round.
- **Clearer Warm-up**: The countdown before Round 1 now shows Get Ready.

### Fixed

- **Round One Start**: The challenge no longer stops by itself when the first round begins.
- **Restart After Winning**: The Controller works again after a victory.
- **Health Penalties**: Lost maximum health is restored when a challenge ends.

## [1.9.0] - 2026-10-29

### Improved & Balanced

- **Changelog started**: Version history is recorded from this release onward.
