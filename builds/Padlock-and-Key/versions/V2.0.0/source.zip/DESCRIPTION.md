# Padlock & Key — Password Locks for Chests and Doors

**By ALNStudios**

[![Minecraft Bedrock](https://img.shields.io/badge/Minecraft%20Bedrock-Stable%20Release-brightgreen?style=flat-square&logo=minecraft)](https://github.com/AllensCreations/MCPE-Curseforges)
[![Format](https://img.shields.io/badge/Format-.MCPACK%20%7C%20.MCADDON%20%7C%20.MCWORLD-blue?style=flat-square)](https://github.com/AllensCreations/MCPE-Curseforges)

**Craft a Padlock from 1 Iron Ingot and 1 Amethyst Shard, name it on an anvil, and lock any chest or door.**

> Padlock & Key adds a Padlock crafted from 1 Iron Ingot and 1 Amethyst Shard, plus a Key that is handed to you when you lock something.

## Overview

Craft a Padlock, rename it on an anvil, and use it on a supported block. The block locks, the Padlock is used up, and you receive a Key carrying the same name.

## Key Features

### Padlock
- **What Happens**: The Padlock is crafted with 1 Iron Ingot and 1 Amethyst Shard.
- **Good To Know**: An unnamed Padlock does not lock anything.

### Key
- **What Happens**: The Key opens a locked container while it is held in your main hand or your offhand and its name matches the password exactly.
- **How It Works**: Locked doors, trapdoors and fence gates cannot be opened by hand, even with the Key, just like an Iron Door. If one still opens, it snaps shut again.
- **Good To Know**: Without a matching Key, the block stays shut, and you see text above your hotbar with angry villager particles.

### Permanent Unlock
- **What Happens**: Sneak and right-click a locked block while holding the matching Key to remove the lock completely.
- **Good To Know**: A normal right-click with the Key only opens a locked container and never removes the lock.

### Break Protection
- **What Happens**: A locked block cannot be broken unless you hold the matching Key in either hand.
- **Good To Know**: Hoppers cannot be placed directly under a locked block, and a block cannot be locked while a Hopper sits under it. Explosions do not destroy locked blocks, and the block under a locked container or door is protected from breaking and explosions. Redstone can still open a locked door, trapdoor or fence gate, like an Iron Door. Mobs that break doors, such as Zombies, are not stopped.

### Key Copies
- **What Happens**: Hold a Key in your main hand and an Iron Nugget in your offhand, then use the Key to get one extra Key with the same name.
- **Good To Know**: Crafting cannot carry a custom name, so copies are made by using the Key instead of in a crafting grid.

### Lockable Blocks
- **What Happens**: Chest, Trapped Chest, every Copper Chest, Ender Chest, Barrel, every Shulker Box, Furnace, Blast Furnace, Smoker, Hopper, Brewing Stand, Dispenser, Dropper, Crafter, Decorated Pot, every door, every Fence Gate, every Trapdoor, and Chiseled Bookshelf can be locked.
- **Good To Know**: Lock data is saved with the world, and each dimension keeps its own locks. A Piston cannot be placed aimed at a locked block, and a block cannot be locked while a Piston is aimed at it. If a Piston still moves a locked block, for example in a Slime Block machine, the lock moves with it and the block stays locked. Locks left behind by a block that no longer exists are removed automatically.

## How to Use

1. Craft a Padlock with 1 Iron Ingot and 1 Amethyst Shard, then rename it on an anvil to your password.
2. Right-click a Chest, door, or other supported block with the Padlock to lock it and receive a Key.
3. Hold the Key in either hand and right-click a container to open it, or sneak and right-click any locked block to unlock it for good.

## Common Questions

- **Can I break a locked Chest?**: Only while you hold its matching Key in either hand. Breaking it removes the lock, disperses the Key, and returns the Padlock.
- **Does the Padlock work when it has no custom name?**: No. Rename it on an anvil first.

## Compatibility

- Minecraft Bedrock Edition: 1.21.60 minimum
- Experimental features: No experiment requirement detected in the inspected files.
- Achievements: Likely achievement-friendly.
- Verification: Source created, not tested in game.

## Creator and Permissions

- Creator: ALNStudios
- Profiles: [CurseForge Profile](https://www.curseforge.com/members/allenscreations/projects) · [MCPEDL Profile](https://mcpedl.com/user/alnstudios/)

<a href="https://www.curseforge.com/members/allenscreations/projects"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/curseforge.jpg" alt="CurseForge" width="45%"></a> <a href="https://mcpedl.com/user/alnstudios/"><img src="https://raw.githubusercontent.com/AllensCreations/MCPE-Curseforges/main/assets/Images/MCPEDL.jpg" alt="MCPEDL" width="45%"></a>

## Guidelines and Attribution

- Creator: ALNStudios
- Rights & Reservation: All rights reserved for ALNStudios.
- Content Creators: Content creators are permitted to feature this creation in videos and streams with credit to ALNStudios.
- Redistribution: Do not re-upload this pack or provide direct monetized download bypasses. Link directly to the official repository page.
- Disclaimer: This is an unofficial community creation. It is not an official Minecraft product and is not approved by or associated with Mojang or Microsoft.

---

© All rights reserved for ALNStudios.

---

## Search & Discovery Keywords

Minecraft Bedrock add-on, Padlock & Key Bedrock mod, chest lock, door lock, password lock, Padlock, Key, anvil rename, Minecraft PE survival, MCPEDL add-on, CurseForge Bedrock, ALNStudios.

