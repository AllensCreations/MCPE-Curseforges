# Universal Clutch (v1.0.3)

Download the current release of **Universal Clutch** for Minecraft Bedrock Edition.

## Download

- **Version:** 1.0.3
- **Package format:** `.mcpack`
- **Direct download:** [Download Universal Clutch (.mcpack)](https://github.com/AllensCreations/MCPE-Curseforges/raw/main/builds/Universal-Clutch/Universal%20Clutch%20by%20AllensCreations%20%28V1.0.3%29.mcpack)

## Installation

1. Download the package using the link above.
2. Open the downloaded file with Minecraft to import it.
3. If the package contains a pack that must be enabled separately, activate it in your world's settings.

## Add-on Information

For gameplay features, usage details, recipes, compatibility notes, and other project information, read the [full description](https://github.com/AllensCreations/MCPE-Curseforges/blob/main/MCPEDL/addons/Universal-Clutch/DESCRIPTION.md).
