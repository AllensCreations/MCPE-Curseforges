export const HARDMODE = true;
