export const HARDMODE = false;
