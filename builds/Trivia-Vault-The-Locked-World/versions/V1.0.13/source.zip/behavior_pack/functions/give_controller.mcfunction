give @s allenscreations:controller
